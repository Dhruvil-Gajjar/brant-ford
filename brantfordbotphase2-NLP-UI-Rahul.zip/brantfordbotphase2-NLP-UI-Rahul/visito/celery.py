import os
from celery import Celery

# Celery Settings
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'visito.settings')
BASE_REDIS_URL = os.environ.get('REDIS_URL', 'redis://localhost:6379')

app = Celery(
    'visito',
    broker_connection_retry=False,
    broker_connection_retry_on_startup=True,
    broker_connection_max_retries=10
)

app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks()

app.conf.broker_url = BASE_REDIS_URL


# ####   Start services   #####
""" Local env """
# celery -A visito worker -l INFO --pidfile="worker.pid"
""" Production env """
# celery -A visito worker -l INFO --pidfile="worker.pid" --logfile="/home/ubuntu/logs/worker.log" --detach
