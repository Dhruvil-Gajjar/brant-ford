# Register your models here.
from django.contrib import admin

from form_generation.models import Patient, FormToken, PatientToken, Clinic

admin.site.register(Patient)
admin.site.register(FormToken)
admin.site.register(PatientToken)
admin.site.register(Clinic)
