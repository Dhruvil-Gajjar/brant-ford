import pytz
from dateutil.relativedelta import relativedelta
from django.core.validators import RegexValidator
from django.db import models
from django.utils import timezone

# different clinics
class Clinic(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255, unique=True, blank=True, null=False)
    def __str__(self):
        return f'{self.name.title()}'

# patient information
class Patient(models.Model):
    class Gender(models.TextChoices):
        MALE = 'M'
        FEMALE = 'F'
        OTHER = 'O'
        PREFER_NOT_TO_DISCLOSE = 'U'

    class MaritalStatus(models.TextChoices):
        SINGLE = 'S'
        MARRIED = 'M'
        COMMON_LAW = 'C'
        LEGALLY_SEPARATED = 'L'
        DIVORCED = 'D'
        WIDOWED = 'W'
        LIFE_PARTNER = 'P'
        UNKNOWN = 'U'

    class Province(models.TextChoices):
        ALBERTA = 'AB'
        BRITISH_COLUMBIA = 'BC'
        MANITOBA = 'MB'
        NEW_BRUNSWICK = 'NB'
        NEWFOUNDLAND_AND_LABRADOR = 'NL'
        NOVA_SCOTIA = 'NS'
        ONTARIO = 'ON'
        PRINCE_EDWARD_ISLAND = 'PE'
        QUEBEC = 'QC'
        SASKATCHEWAN = 'SK'
        NORTHWEST_TERRITORIES = 'NT'
        YUKON = 'YK'
        NUNAVUT = 'NU'

    class Country(models.TextChoices):
        CANADA = 'CA'
        UNITED_STATES = 'US'

    BOOLEAN_CHOICES = (
        (None, 'N/A'),
        (True, 'Yes'),
        (False, 'No')
    )

    class EmploymentStatus(models.TextChoices):
        FULL_TIME = 'FT'
        PART_TIME = 'PT'
        NOT_EMPLOYED = 'NE'
        SELF_EMPLOYED = 'SE'
        RETIRED = 'RE'
        STUDENT = 'ST'
        STUDENT_PART_TIME = 'SP'
        HOME_MAKER = 'HM'
        MILITARY_DUTY = 'MD'
        UNKNOWN = 'UN'

    # Validators
    phone_regex = RegexValidator(regex=r'^\+?1?\d{10,13}$',
                                 message="Phone number must be entered in the format: '+999999999'. "
                                         "From 10 to 13 digits allowed.")

    id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=255, blank=False, null=False)
    last_name = models.CharField(max_length=255, blank=False, null=False)
    middle_name = models.CharField(max_length=255, blank=True, null=True)
    gender = models.CharField(max_length=1, choices=Gender.choices, blank=False, null=False)
    health_card_number = models.CharField(max_length=255, blank=False, null=False)
    health_card_version = models.CharField(max_length=255, blank=True, null=True)
    date_of_birth = models.DateField(null=False, blank=False)
    phone_number = models.CharField(max_length=20, blank=False, null=False, validators=[phone_regex])
    email = models.EmailField(max_length=50, null=False, blank=False)
    clinic = models.ForeignKey(Clinic, on_delete=models.CASCADE, blank=False, null=False)
    address_number = models.CharField(max_length=10, blank=False, null = False)
    address_street = models.CharField(max_length=255, blank=False, null = False)
    apartment_po_box = models.CharField(max_length=10, blank=True, null=True)
    address_city = models.CharField(max_length=255, blank=False, null=False)
    address_province = models.CharField(max_length=2, choices=Province.choices, default=Province.ONTARIO, blank=False, null=False)
    address_country = models.CharField(max_length=2, choices=Country.choices, default=Country.CANADA, blank=False, null = False)
    address_postal_code = models.CharField(max_length=7, blank=False, null=False)
    family_doctor = models.CharField(max_length=255, blank=True, null=True)
    referring_doctor = models.CharField(max_length=255, blank=True, null=True)
    mother_first_name = models.CharField(max_length=255, blank=True, null=True)
    mother_last_name = models.CharField(max_length=255, blank=True, null=True)
    mother_date_of_birth = models.DateField(blank=True, null=True)
    mother_marital_status = models.CharField(max_length=1, choices=MaritalStatus.choices, blank=True, null=True)
    mother_health_card_number = models.CharField(max_length=255, blank=True, null=True)
    mother_health_card_version = models.CharField(max_length=255, blank=True, null=True)
    live_with_mother = models.BooleanField(choices=BOOLEAN_CHOICES, null=True, blank=True)
    mother_employment_status = models.CharField(max_length=2, choices=EmploymentStatus.choices, blank=True)
    mother_employer = models.CharField(max_length=255, blank=True, null=True)
    father_first_name = models.CharField(max_length=255, blank=True, null=True)
    father_last_name = models.CharField(max_length=255, blank=True, null=True)
    father_date_of_birth = models.DateField(blank=True, null=True)
    father_marital_status = models.CharField(max_length=1, choices=MaritalStatus.choices, blank=True, null=True)
    father_health_card_number = models.CharField(max_length=255, blank=True, null=True)
    father_health_card_version = models.CharField(max_length=255, blank=True, null=True)
    live_with_father = models.BooleanField(choices=BOOLEAN_CHOICES, null=True, blank=True)
    father_employment_status = models.CharField(max_length=2, choices=EmploymentStatus.choices, blank=True, null=True)
    father_employer = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return f'{self.id}: {self.first_name} {self.last_name} - DOB: {self.date_of_birth}'

    def get_age(self):
        today = timezone.now().astimezone(pytz.timezone('America/Toronto')).date()
        difference = relativedelta(today, self.date_of_birth)
        age = difference.years * 12 + difference.months
        return age


class FormToken(models.Model):
    value = models.CharField(max_length=36, unique=True, blank=False, null=False)
    valid_until = models.DateTimeField(null=False)


class PatientToken(models.Model):
    value = models.CharField(max_length=36, unique=True, blank=False, null=False)
    valid_until = models.DateTimeField(blank=True, null=True)
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, blank=False, null=False)
