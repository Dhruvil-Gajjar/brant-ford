from django import forms
from django.core.exceptions import ValidationError
from django.db import models
from django.forms import ModelForm

from form_generation.models import Patient
from nlp.models import Intent, GroupInfo

CLASS_STYLE = 'form-control col-md-7 col-xs-12'


class DateInput(forms.DateInput):
    input_type = 'date'


class GenerateForm(forms.Form):
    class DetailLevel(models.IntegerChoices):
        LITTLE = 0
        MEDIUM = 1
        MAX = 2

    patient = forms.ModelChoiceField(queryset=Patient.objects.all(), required=False,
                                     widget=forms.Select(attrs={'class': CLASS_STYLE}))
    email = forms.EmailField(widget=forms.EmailInput(attrs={'class': CLASS_STYLE}))
    phone_number = forms.CharField(widget=forms.TextInput(attrs={'class': CLASS_STYLE}))
    complaint = forms.MultipleChoiceField(choices=[], widget=forms.SelectMultiple(attrs={'class': 'form-control',
                                                                                         'size': "10"}))
    history_level = forms.ModelMultipleChoiceField(queryset=Intent.objects.filter(section_id=2).order_by('intent_name'),
                                                   widget=forms.CheckboxSelectMultiple())
    detail_level = forms.ChoiceField(choices=DetailLevel.choices)

    def __init__(self, *args, **kwargs):
        super(GenerateForm, self).__init__(*args, **kwargs)
        choices = []
        for intent in Intent.objects.order_by('intent_name'):
            choices.append((intent.intent_id, intent.__str__()))
        choices.sort(key=lambda x: x[1].lower())
        self.fields['complaint'].choices = choices

    def clean_history_level(self):
        data = self.cleaned_data['history_level']
        if len(data) < 1:
            raise ValidationError('You must select at least one choice.')
        return data

    def clean_complaint(self):
        data = self.cleaned_data['complaint']
        errors = []
        if len(data) < 1:
            errors.append('You must select at least one complaint.')

        if len(data) > 3:
            errors.append('You cannot select more than 3 complaints.')

        if len(errors) > 0:
            raise ValidationError(' '.join(errors))
        return data

# registration form model template 
class PatientRegistrationForm(ModelForm):
    class Meta:
        model = Patient
        exclude = ('id',)
        widgets = {
            'first_name': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'last_name': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'middle_name': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'gender': forms.Select(attrs={'class': CLASS_STYLE}),
            'health_card_number': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'health_card_version': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'date_of_birth': DateInput(attrs={'class': CLASS_STYLE}),
            'phone_number': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'email': forms.EmailInput(attrs={'class': CLASS_STYLE}),
            'clinic': forms.Select(attrs={'class': CLASS_STYLE}),
            'address_number': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'address_street': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'apartment_po_box': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'address_city': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'address_province': forms.Select(attrs={'class': CLASS_STYLE}),
            'address_country': forms.Select(attrs={'class': CLASS_STYLE}),
            'address_postal_code': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'family_doctor': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'referring_doctor': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'mother_first_name': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'mother_last_name': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'mother_date_of_birth': DateInput(attrs={'class': CLASS_STYLE}),
            'mother_marital_status': forms.Select(attrs={'class': CLASS_STYLE}),
            'mother_health_card_number': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'mother_health_card_version': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'live_with_mother': forms.Select(attrs={'class': CLASS_STYLE}),
            'mother_employment_status': forms.Select(attrs={'class': CLASS_STYLE}),
            'mother_employer': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'father_first_name': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'father_last_name': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'father_date_of_birth': DateInput(attrs={'class': CLASS_STYLE}),
            'father_marital_status': forms.Select(attrs={'class': CLASS_STYLE}),
            'father_health_card_number': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'father_health_card_version': forms.TextInput(attrs={'class': CLASS_STYLE}),
            'live_with_father': forms.Select(attrs={'class': CLASS_STYLE}),
            'father_employment_status': forms.Select(attrs={'class': CLASS_STYLE}),
            'father_employer': forms.TextInput(attrs={'class': CLASS_STYLE})
        }


class ConfirmIdentityForm(GenerateForm):
    def __init__(self, *args, **kwargs):
        super(ConfirmIdentityForm, self).__init__(*args, **kwargs)
        self.fields.pop('email')
        self.fields.pop('phone_number')
