from django.apps import AppConfig


class FormGenerationConfig(AppConfig):
    name = 'form_generation'
