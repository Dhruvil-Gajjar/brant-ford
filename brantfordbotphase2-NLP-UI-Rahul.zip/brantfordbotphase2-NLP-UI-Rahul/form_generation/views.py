import json

import pytz

from datetime import datetime, timedelta
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from django.urls import reverse
from django.utils.http import urlencode
from typing import Union, Literal
from uuid import uuid4

from django.views.decorators.http import require_http_methods

from form_generation.forms import GenerateForm, PatientRegistrationForm, ConfirmIdentityForm
from form_generation.models import FormToken, Patient, PatientToken
from nlp.models import Question, Intent, ChatInfo, Response, GroupQuestion
from account.tasks import generate_otp, send_message_visito


# generates dynamic form based on the information entered.
@login_required
@require_http_methods(['GET', 'POST'])
def generate_form(request):
    if request.method == 'POST':
        generated_form = GenerateForm(request.POST)
        if generated_form.is_valid():
            token = generate_random_token('form')
            patient = generated_form.cleaned_data['patient']
            complaint = generated_form.cleaned_data['complaint']
            history = list(generated_form.cleaned_data['history_level'].values_list(flat=True))
            detail = generated_form.cleaned_data['detail_level']
            if token is not None:
                token.save()
                if patient:
                    client_token = PatientToken.objects.filter(patient=patient).first()
                    if client_token is not None:
                        send_message_visito.delay(client_token.patient.phone_number, client_token.value)
                        clinical_form_url = reverse_querystring('form_generation:confirm_identity',
                                                                query_kwargs={'id': patient.id,
                                                                              'token': token.value,
                                                                              'complaint': complaint,
                                                                              'history': history,
                                                                              'detail': detail})
                        return redirect(clinical_form_url)
                    else:
                        messages.error(request, 'This patient does not have an assigned token. '
                                                'Please contact the administrator.')
                else:
                    registration_form_url = reverse_querystring('form_generation:registration_form',
                                                                query_kwargs={'token': token.value,
                                                                              'complaint': complaint,
                                                                              'history': history,
                                                                              'detail': detail})
                    return redirect(registration_form_url)
            else:
                messages.error(request, 'An invalid token type was used to generate this request. '
                                        'Please contact the administrator')
        else:
            messages.error(request, 'There was an error generating this form. Please fix the below errors')
        form = generated_form
    else:
        form = GenerateForm()

    context = {'form': form}
    return render(request, 'form_generation/generate_form.html', context)


# patient registration 
@require_http_methods(['GET', 'POST'])
def registration_form(request):
    token = request.GET.get('token')
    if token is None or not is_token_valid('form', token):
        return redirect('form_generation:expired')

    if request.method == 'GET':
        form = PatientRegistrationForm()
    else:
        # TODO DHRUVIL SMS auth
        patient_form = PatientRegistrationForm(request.POST)
        if patient_form.is_valid():
            new_patient = patient_form.save()
            client_token = generate_random_token('patient', new_patient.id)
            if client_token is not None:
                client_token.save()
                send_message_visito.delay(new_patient.phone_number, client_token.value)
                registration_confirm_url = reverse_querystring('form_generation:registration_confirm',
                                                               query_kwargs={'client': client_token.value,
                                                                             'token': token})
                return redirect(registration_confirm_url)
            else:
                messages.error(request, 'There was an error generating this form. Please fix the below errors')
        form = patient_form

    context = {'form': form}
    return render(request, 'form_generation/patient_registration.html', context)


# registration of patient after verification
@require_http_methods(['GET'])
def registration_confirm(request):
    form_token = request.GET.get('token')
    client_token = request.GET.get('client')
    if form_token is None or client_token is None:
        return redirect('form_generation:expired')

    retrieved_form_token = FormToken.objects.filter(value=form_token).first()
    retrieved_client_token = PatientToken.objects.filter(value=client_token).first()
    if retrieved_form_token is None or retrieved_client_token is None:
        return redirect('form_generation:expired')

    context = {'client_token': client_token}
    return render(request, 'form_generation/registration_confirm.html', context)


# patient information submission 
@require_http_methods(['GET', 'POST'])
def clinical_patient_identify(request):
    token = request.GET.get('token')
    if token is None or not is_token_valid('form', token):
        return redirect('form_generation:expired')

    patient_id = request.GET.get('id')
    complaint = request.GET.getlist('complaint')
    history_level = request.GET.getlist('history')
    detail_level = request.GET.get('detail')
    patient = Patient.objects.filter(id=patient_id).first()
    if not all([[patient_id, complaint, history_level, detail_level, patient]]):
        return redirect('form_generation:bad_request')

    if request.method == 'POST':
        post_data = request.POST.copy()
        # TODO DHRUVIL SMS AUTH 
        client_token = post_data.pop('client_token', None)[0]
        # Check that the hidden form values are still valid, if it is then we can check for a matching token
        generated_form = ConfirmIdentityForm(post_data)
        if generated_form.is_valid():
            if is_token_valid('client', client_token) and is_token_match(generated_form.cleaned_data['patient'],
                                                                         client_token):
                clinical_form_url = reverse_querystring('form_generation:clinical_form',
                                                        query_kwargs={'id': patient.id,
                                                                      'token': token,
                                                                      'complaint': complaint,
                                                                      'history': history_level,
                                                                      'detail': detail_level})
                request.session['pp_clinical_patient_identify'] = True  # Used to confirm redirect occurred
                return redirect(clinical_form_url)
            else:
                messages.error(request, 'The token you entered is not valid. Please try again. If you have forgotten '
                                        'your token, you may contact the office to have it reset.')
        else:
            return redirect('form_generation:bad_request')

    context = {'patient_id': patient_id,
               'complaint': complaint,
               'history_level': history_level,
               'detail_level': detail_level}

    return render(request, 'form_generation/clinical_patient_identify.html', context)


@require_http_methods(['GET', 'POST'])
def clinical_form(request):
    token = request.GET.get('token')
    if token is None or not is_token_valid('form', token):
        return redirect('form_generation:expired')

    if request.method == 'POST':
        form_data = request.POST.copy()
        patient = Patient.objects.get(pk=form_data.get('patient'))
        form_data.pop('patient', None)
        form_data.pop('csrfmiddlewaretoken', None)

        session = ChatInfo(name=f'{patient.first_name.lower()} {patient.last_name.lower()}',
                           email_address=patient.email,
                           date_of_birth=patient.date_of_birth,
                           sex=patient.gender,
                           first_visit=False,
                           registration_form=True,
                           clinical_form=True,
                           chat_ended=datetime.utcnow().replace(tzinfo=pytz.utc))
        session.full_clean()
        session.save()

        for question_id, answer in form_data.lists():
            response = Response()
            # For now just save the questions with their IDs, will have to see if we need their groups
            if 'group' in question_id:
                split_question = question_id.split('_')
                question_id = split_question[-1]
                response.group_item_number = split_question[-2]
            question = Question.objects.filter(pk=question_id).first()
            if question:
                response.chat_id_id = session.pk
                response.question_id = question

                if isinstance(answer, list):
                    response.answer = ", ".join(answer)
                else:
                    response.answer = answer[0]

                if response.answer != '':
                    response.full_clean()
                    response.save()

        return redirect('form_generation:generate_form')

    else:
        patient_id = request.GET.get('id')
        complaint = request.GET.getlist('complaint')
        history_level = request.GET.getlist('history')
        detail_level = request.GET.get('detail')
        patient = Patient.objects.filter(id=patient_id).first()
        if not all([[patient_id, complaint, history_level, detail_level, patient]]):
            return redirect('form_generation:bad_request')

        # Checks whether the user was redirected to this page, if they went to the url directly they have to reconfirm
        # their client token
        if 'pp_clinical_patient_identify' in request.session:
            all_intents = complaint + history_level
            intent_items = []
            follow_up_list = []
            # Get the questions for the complaints
            for intent in all_intents:
                questions_for_intent = Question.objects.filter(intent_id=intent).order_by('question_order',
                                                                                          'question_sub_order')
                question_list = Question.filter_questions(questions_for_intent, patient, detail_level)
                group_questions = []

                # Get group questions to find their follow up questions
                for q in question_list:
                    if q.group_id:
                        group_q = GroupQuestion.objects.filter(group_id=q.group_id)
                        group_questions.extend([gq.question_id for gq in group_q])

                # Get all potential follow up questions for the intent
                follow_up = Question.get_follow_up_questions(question_list + group_questions, [])
                if len(follow_up) > 0:
                    follow_up_list.extend(follow_up)

                question_list = [question.to_json() for question in question_list]
                question_list = Question.aggregate_questions_by_order(question_list)

                if len(question_list) > 0:
                    intent_questions = {'intent_name': Intent.objects.filter(pk=intent).first().__str__(),
                                        'questions': question_list}
                    intent_items.append(intent_questions)

            context = {'intents': json.dumps(intent_items),
                       'single_select': [7, 11, 12, 15, 17],
                       'multiple_select': [5, 13, 14, 16, 18],
                       'radio_buttons': [3, 4],
                       'patient': patient_id,
                       'follow_up_list': json.dumps(follow_up_list)}

            # del request.session['pp_clinical_patient_identify']
            return render(request, 'form_generation/clinical_form.html', context)
        else:
            return redirect(reverse_querystring('form_generation:confirm_identity',
                                                query_kwargs={'id': patient.id,
                                                              'token': token,
                                                              'complaint': complaint,
                                                              'history': history_level,
                                                              'detail': detail_level}))


def expired(request):
    return render(request, 'form_generation/expired.html')


def unauthorized(request):
    return render(request, 'form_generation/unauthorized.html')


def bad_request(request):
    return render(request, 'form_generation/bad_request.html')


def generate_random_token(token_type: str, patient_id: int = None) -> Union[FormToken, PatientToken, None]:
    rand_token = str(generate_otp())
    if token_type == 'form':
        while FormToken.objects.filter(value=rand_token).first():
            rand_token = str(generate_otp())
        days_valid = 7
        return FormToken(value=rand_token, valid_until=calculate_valid_until(days_valid))
    elif token_type == 'patient':
        patient = Patient.objects.filter(pk=patient_id).first()
        if patient is None:
            return None
        while PatientToken.objects.filter(value=rand_token).first():
            rand_token = str(generate_otp())
        # Client tokens don't expire by default, don't need to use valid_until field
        return PatientToken(value=rand_token, patient=patient)
    else:
        return None


def calculate_valid_until(days: int = 7) -> datetime:
    if days < 1:
        days = 7
    return datetime.now(pytz.utc) + timedelta(days=days)


def is_token_valid(token_type: Literal['form', 'client'], token_value: str) -> bool:
    if token_type is None or token_value is None:
        return False

    if token_type == 'form':
        retrieved_token = FormToken.objects.filter(value=token_value).first()
    elif token_type == 'client':
        retrieved_token = PatientToken.objects.filter(value=token_value).first()
    else:
        return False

    if retrieved_token is None:
        return False
    elif retrieved_token.valid_until is None:
        return True
    else:
        return retrieved_token.valid_until >= datetime.now(pytz.utc)


def is_token_match(patient: Patient, token_value: str) -> bool:
    if patient is None or token_value is None:
        return False

    retrieved_token = PatientToken.objects.filter(value=token_value).first()
    if retrieved_token is None:
        return False

    return retrieved_token.patient_id == patient.id


def reverse_querystring(view, urlconf=None, args=None, kwargs=None, current_app=None, query_kwargs=None):
    """Custom reverse to handle query strings.
    Usage:
        reverse('app.views.my_view', kwargs={'pk': 123}, query_kwargs={'search': 'Bob'})
    """
    base_url = reverse(view, urlconf=urlconf, args=args, kwargs=kwargs, current_app=current_app)
    if query_kwargs:
        return '{}?{}'.format(base_url, urlencode(query_kwargs, True))
    return base_url
