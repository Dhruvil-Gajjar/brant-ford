from django.urls import include, path
from . import views

app_name = 'form_generation'

urlpatterns = [
    path('generate/', views.generate_form, name='generate_form'),
    path('patient_registration/', views.registration_form, name='registration_form'),
    path('registration_confirm/', views.registration_confirm, name='registration_confirm'),
    path('confirm_identity/', views.clinical_patient_identify, name='confirm_identity'),
    path('clinical/', views.clinical_form, name='clinical_form'),
    path('401/', views.unauthorized, name='unauthorized'),
    path('498/', views.expired, name='expired'),
    path('400/', views.bad_request, name='bad_request')
]
