// Modification by: Mervat Mustafa (MM)
// Modification Date: summer, 2021
$(document).ready(function () {
  var is_segment = false
  var is_sub_segment = false
  var range_max_list = [];
  var range_min_list = [];
  var segment_input = '';
  var segment_qu_id = '';
  var email_id = null
  // autocopleted 
  function autocomplete(inp, arr) {
    /*the autocomplete function takes two arguments,
    the text field element and an array of possible autocompleted values:*/
    var currentFocus;
    /*execute a function when someone writes in the text field:*/
    inp.addEventListener("input", function (e) {
      var a, b, i, val = this.value;
      /*close any already open lists of autocompleted values*/
      closeAllLists();
      if (!val) { return false; }
      currentFocus = -1;
      /*create a DIV element that will contain the items (values):*/
      a = document.createElement("DIV");
      a.setAttribute("id", this.id + "autocomplete-list");
      a.setAttribute("class", "autocomplete-items");
      /*append the DIV element as a child of the autocomplete container:*/
      this.parentNode.appendChild(a);
      /*for each item in the array...*/
      for (i = 0; i < arr.length; i++) {
        /*check if the item starts with the same letters as the text field value:*/
        if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
          /*create a DIV element for each matching element:*/
          b = document.createElement("DIV");
          /*make the matching letters bold:*/
          b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
          b.innerHTML += arr[i].substr(val.length);
          /*insert a input field that will hold the current array item's value:*/
          b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
          /*execute a function when someone clicks on the item value (DIV element):*/
          b.addEventListener("click", function (e) {
            /*insert the value for the autocomplete text field:*/
            inp.value = this.getElementsByTagName("input")[0].value;
            /*close the list of autocompleted values,
            (or any other open lists of autocompleted values:*/
            closeAllLists();
          });
          a.appendChild(b);
        }
      }
    });
    /*execute a function presses a key on the keyboard:*/
    inp.addEventListener("keydown", function (e) {
      var x = document.getElementById(this.id + "autocomplete-list");
      if (x) x = x.getElementsByTagName("div");
      if (e.keyCode == 40) {
        /*If the arrow DOWN key is pressed,
        increase the currentFocus variable:*/
        currentFocus++;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 38) { //up
        /*If the arrow UP key is pressed,
        decrease the currentFocus variable:*/
        currentFocus--;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 13) {
        /*If the ENTER key is pressed, prevent the form from being submitted,*/
        e.preventDefault();
        if (currentFocus > -1) {
          /*and simulate a click on the "active" item:*/
          if (x) x[currentFocus].click();
        }
      }
    });
    function addActive(x) {
      /*a function to classify an item as "active":*/
      if (!x) return false;
      /*start by removing the "active" class on all items:*/
      removeActive(x);
      if (currentFocus >= x.length) currentFocus = 0;
      if (currentFocus < 0) currentFocus = (x.length - 1);
      /*add class "autocomplete-active":*/
      x[currentFocus].classList.add("autocomplete-active");
    }
    function removeActive(x) {
      /*a function to remove the "active" class from all autocomplete items:*/
      for (var i = 0; i < x.length; i++) {
        x[i].classList.remove("autocomplete-active");
      }
    }
    function closeAllLists(elmnt) {
      /*close all autocomplete lists in the document,
      except the one passed as an argument:*/
      var x = document.getElementsByClassName("autocomplete-items");
      for (var i = 0; i < x.length; i++) {
        if (elmnt != x[i] && elmnt != inp) {
          x[i].parentNode.removeChild(x[i]);
        }
      }
    }
    /*execute a function when someone clicks in the document:*/
    document.addEventListener("click", function (e) {
      closeAllLists(e.target);
    });
  }

  ///



  $(".open-button").show()


  $(".login-form-container").hide()
  $(".chat-popup").hide()


  $(".open-button").click(function () {

    //document.getElementsByClassName("chat-container").style.display = "block";
    //$(".open-button").hide()
    if (email_id == null) {
      $(".login-form-container").toggle()
      $(".chat-popup").hide()
    }

    else {
      $(".login-form-container").hide()
      $(".chat-popup").show()
      $(".open-button").hide()

    }

  })

  $('#datetimepicker').datetimepicker({
    formatTime: "h:i a",
    step: 30,
    validateOnBlur: false,
    format: "d/m/Y h:i a",
    mask: true
  });

  function isEmail(email) {
    var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!regex.test(email)) {
      return false;
    }
    else {
      return true;
    }
  }


  $(document).on("focus", "#datetimepicker", function () {
    $('#datetimepicker').datetimepicker({
      formatTime: "h:i a",
      step: 30,
      validateOnBlur: false,
      format: "d/m/Y h:i a",
      mask: true
    }).focus();
  })

  $(document).on("click", ".pop-up-text-multi", function () {
    $(this).toggleClass('highlight')

    if ($(this).attr("id") != null) {
      if ($(this).attr("id").startsWith('S-'))
        if ($(this).attr("id").endsWith('-clicked'))

          $(this).attr("id", $(this).attr("id").substring(0, $(this).attr("id").indexOf('-clicked')))
        else
          $(this).attr("id", $(this).attr("id") + '-clicked')
    }


  })
  if (isEmail($("#email").val())) {
    if ($('.alert-email').length != 0) {
      $(".alert-email").remove()
    }
  }

  $("#start-chat").click(function () {

    var user_email = $("#email").val();
    var fname = $("#fname").val()
    //var date = new Date($("#dob").val())
    var date_of_birth = ($("#dob").val())
    var current_date = new Date();
    dob = new Date(date_of_birth)

    if ($("#email").val().length == 0 || $("#fname").val().length == 0 || $("#dob").val().length == 0) {
      if ($('.alert_enter').length == 0) {
        var alert_enter = '<div class = "alert_enter"><p class = "text-danger">Please enter all values</p></div>'
        $(alert_enter).insertBefore("#start-chat")
      }
      //alert("Please enter all values");
    }
    //alert(dob>current_date)
    else if (dob > current_date) {
      if ($('.alert-date').length == 0) {
        var alert_date = '<div class = "alert-date"><p class = "text-danger">Please enter a date before today</p></div>'
        $(alert_date).insertBefore("#start-chat")
      }
    }
    else if (!isEmail($("#email").val())) {
      if ($('.alert-email').length == 0) {
        var alert_email = '<div class = "alert-email"><p class = "text-danger">Please enter a valid email address</p></div>'
        $(alert_email).insertBefore("#label-fname")
      }
    }


    else {
      $.ajax({
        type: 'POST',
        //contentType: "application/json",
        url: '/start-chat/',
        data: {
          'email': user_email,
          'fname': fname,
          'dob': date_of_birth

        },
        //processData: false,

        dataType: 'json',
        success: function (data) {
          console.log("success");
          email_id = data["message"]["session"]


          console.log(email_id)
          $(".login-form-container").hide()
          $(".chat-popup").show()
          $(".open-button").hide()
          $("#start").hide()

          document.getElementById("logged-in-as").innerHTML = email_id
          $("#user-input").val("meme")

          document.getElementById("send-btn").click();

        },
        error: function (xhr, status, error) {
          alert("error")
          console.log(" xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: " + error);

        }
      });


    }

  })




  var chat_pop_up_width = $(".chat-popup").width()

  $(".container").width(chat_pop_up_width)
  //$(".msg-bottom").width(chat_pop_up_width)

  //alert(chat_pop_up_width - $(".msg-bottom").width())


  $(".expand-div").click(function () {
    if ($("i").hasClass("fa-compress-arrows-alt")) {
      $(".chat-popup").css({
        "position": "fixed",
        "bottom": "120px",
        "right": "15px",
        "border": "3px solid #f1f1f1",
        "z-index": "9",
        "width": "30%",
        "height": "80vh"
      });

      $(".fa-compress-arrows-alt").replaceWith('<i class="fas fa-expand-arrows-alt"></i>')
      var chat_pop_up_width = $(".chat-popup").width()
      $(".container").width(chat_pop_up_width)
      //$(".msg-bottom").width(chat_pop_up_width)
      $(".msg-bottom").css({
        "width": "100%",
        "margin-left": "0%"
      })
      $(".expand-div").css({
        "color": "#737373"
      });
      $(".fa-expand-arrows-alt").css({
        "color": "#737373"
      });

    }
    else {
      $(".chat-popup").css({
        "position": "static",
        "width": "60%",
        "margin-left": "20%",
        "margin-top": "2%",
        "height": "80vh"
      });
      $(".pop-up-top").css({
        "position": "relative"
      });
      $(".min-max-close-buttons").css({
        "position": "absolute",
        "right": "0",
        "margin-top": "20px",
        "margin-right": "10px",
        "color": "#333333"
      });
      $(".expand-div").css({
        "color": "#737373"
      });
      $(".fa-expand-arrows-alt").css({
        "color": "#737373"
      });
      $(".container").css({
        "width": "100%"
      });
      $(".msg-bottom").css({
        "position": "relative",
        "height": "10%"
      });
      $(".input-group").css({
        "height": "60%",
        "position": "absolute",
        "top": "20%",
        "float": "right",
        "border-radius": "20%",
        "margin-left": "5%",
        "width": "90%",

      });
      $(".chats").css({
        "padding-top": "10px",
        "padding-right": "15px",
        "padding-bottom": "0px",
        "padding-left": "25px",
        "margin-left": "5%"
      });
      $("#show-login").css({
        "margin-left": "5%"
      })

      var chat_pop_up_width = $(".chat-popup").width()

      //alert(chat_pop_up_width)
      /*$(".container").width(chat_pop_up_width)
      $(".msg-bottom").width(chat_pop_up_width)
      $(".msg-bottom").css({
        "width":"98.3%",
        "margin-left":"5px"

      })*/

      //$(".expand-div").html("contract")
      $(".fa-expand-arrows-alt").replaceWith('<i class="fas fa-compress-arrows-alt"></i>')
    }

  })

  $(".min").click(function () {
    document.getElementById("myForm").style.display = "none";
    $(".open-button").show()
    $(".chat-popup").hide()


  })

  $(".close").click(function () {


    document.getElementById("myForm").style.display = "none";
    $.ajax({
      type: 'POST',
      url: '/end-session/',
      data: {
        'input': email_id
      },
      dataType: 'json',
      success: function (data) {
        console.log("session ended")
        email_id = null;


        $(".login-form-container").hide()
        $(".chat-popup").hide()

        $("#email").val("");
        location.reload(true);
        email_id = null;


      },
      error: function (xhr, status, error) {
        alert("error")
        console.log(" xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: " + error);

      }
    })


    $(".open-button").show()



  })






  $(".chat-animation").hide()

  var currentdate = new Date();
  var datetime = currentdate.getHours() + ":" + currentdate.getMinutes()

  document.getElementById("first-message-time").innerHTML = datetime


  var input_field = document.getElementById("user-input")


  // Execute a function when the user releases a key on the keyboard
  input_field.addEventListener("keyup", function (event) {
    // Number 13 is the "Enter" key on the keyboard
    if (event.keyCode === 13) {
      // Cancel the default action, if needed
      event.preventDefault();
      // Trigger the button element with a click
      document.getElementById("send-btn").click();
    }
  });

  $(document).on("click", ".pop-up", function () {

    pop_up_elment = []
    if ($(this).attr("id") != null) {
      pop_up_element = document.querySelectorAll('[id^="' + $(this).attr("id") + '"]')
      for (var i = 0; i < pop_up_element.length; i++) {
        pop_up_element[i].setAttribute("id", $(this).attr("id"))
        pop_up_element[i].setAttribute("class", 'pop-up')
      }
      $(this).attr('class', 'pop-up-selected');
      $(this).attr("id", $(this).attr("id") + '-clicked');


    }


    if (is_sub_segment != 1) {
      pop_up_val = $(this).find(".pop-up-text").html()
      $('#user-input').removeAttr('disabled');
      $("#user-input").val(pop_up_val)
      $(this).attr('class', 'pop-up-selected');


    }
    if (is_sub_segment == 0) {
      $('.pop-up').prop("disabled", true);
      document.getElementById("send-btn").click();
      $("#send-btn").css("pointer-events", "auto");
    }


  })

  //submit-singleselect

  $(document).on("click", "#submit-singleselect", function () {

    $('#submit-singleselect').prop("disabled", true);
    $('#submit-singleselect').removeAttr('id');
    document.getElementById("send-btn").click();


  })

  $(document).on("click", "#submit-checkboxes-btn", function () {
    check_box_checked = $('input[name="checkboxes-input"]:checked')

    var checked_boxes = []
    $.each(check_box_checked, function () {
      checked_boxes.push($(this).val());
    });


    $('input[name="checkboxes-input"]').removeAttr('name');
    $('#user-input').removeAttr('disabled');
    $("#send-btn").css("pointer-events", "auto")
    $("#submit-checkboxes-btn").attr("disabled", true);

    $("#user-input").val(checked_boxes)

    if (is_sub_segment == 0)
      document.getElementById("send-btn").click();
  })


  $(document).on("click", "#submit-datetime-btn", function () {

    input_datetime = $("#datetimepicker").val()


    $("#datetimepicker").removeAttr('id');
    $('#user-input').removeAttr('disabled');

    $("#send-btn").css("pointer-events", "auto")
    $("#submit-datetime-btn").attr("disabled", true);
    $("#user-input").val(input_datetime)

    document.getElementById("send-btn").click();
  })
  $(document).on("click", "#submit-multiselect", function () {
    var mul_selected_list = []
    $(".pop-up-text-multi.highlight").each(function () {
      mul_selected = ($(this).html())
      mul_selected_list.push(mul_selected)
    })




    $(".pop-up-text-multi").removeAttr('class')
    $(".pop-up-text-multi.highlight").removeAttr('class')
    $("#submit-multiselect").attr("disabled", true);

    $("#user-input").removeAttr('disabled')
    $("#send-btn").css("pointer-events", "auto")

    $("#user-input").val(mul_selected_list)
    document.getElementById("send-btn").click();
  })

  $(document).on("click", "#submit-dropdown", function () {
    var select_option = $("#select-dropdown").val()

    $("#select-dropdown").removeAttr("id")
    $("#submit-dropdown").attr('disabled', true)

    $("#user-input").removeAttr('disabled')
    $("#send-btn").css("pointer-events", "auto")

    $("#user-input").val(select_option)
    document.getElementById("send-btn").click();
  })
  // added by MM
  $(document).on("click", "#submit-text-dropdown", function () {
    var select_option = $("#drop-text").val() + ' ' + $("#select-dropdown").val()

    $("#select-dropdown").removeAttr("id")
    $("#submit-text-dropdown").attr('disabled', true)
    $("#submit-text-dropdown").removeAttr('id')
    $("#user-input").removeAttr('disabled')
    $("#send-btn").css("pointer-events", "auto")

    $("#user-input").val(select_option)
    document.getElementById("send-btn").click();
  })

  $(document).on("click", "#submit-integer", function () {
    var integer_val = $("#text-integer").val()
    $("#text-integer").attr('disabled', true)
    $("#text-integer").removeAttr("id")
    $("#submit-integer").attr('disabled', true)
    $("#submit-integer").removeAttr("id")

    $("#user-input").removeAttr('disabled')
    $("#send-btn").css("pointer-events", "auto")

    $("#user-input").val(integer_val)
    document.getElementById("send-btn").click();
  })



  $(document).on('change', "#select-dropdown", function (e) {
    var index = $('#select-dropdown').find(":selected").index();
    $('#drop-text').attr({ min: range_min_list[index], max: range_max_list[index], value: range_min_list[index] })


  })





  $("#send-btn").click(function () {
    $(".msg-page").animate({ scrollTop: 1000000 }, 1000);

    if ($("#user-input").val() != "start")
      $(".chat-animation").show()
    else
      $(".chat-animation").hide()

    var currentdate = new Date();

    var datetime = currentdate.getHours() + ":"
      + currentdate.getMinutes()

    var input = ''

    input = $("#user-input").val()

    $("#user-input").val("")

    var segment_input_element = [];
    segment_qu_id = ''
    segment_input = ''

    if (is_sub_segment == 2) {
      var val = ''
      segment_input_element = document.querySelectorAll('[id^="S-"]');
      for (var i = 0; i < segment_input_element.length; i++) {
        var element_id = segment_input_element[i].getAttribute('id')
        var end_qu_id_index = element_id.indexOf('-', 2)
        var qu_id = element_id.substring(2, end_qu_id_index)


        //checkbox
        // get checked box val 
        var check_element = [];
        //
        if (segment_input_element[i].getAttribute('type') == 'checkbox') {

          check_element = document.getElementsByClassName('checkboxes-input')

          var checked_boxes = []
          for (var j = 0; j < check_element.length; j++) {
            i++;
            if (check_element[j].checked) {
              checked_boxes.push(check_element[j].value)
            }
            if (check_element[j].getAttribute("name").startsWith('S-' + qu_id)) {
              check_element[j].removeAttribute('class');

            }
          }
          val = checked_boxes

        }
        ////  clicked_pop_up 
        else if (segment_input_element[i].getAttribute('id') == 'S-' + qu_id + '-pop-up-text-clicked') {
          var c = segment_input_element[i].children;
          val = c[0].innerHTML


        }

        // un-clicked pop-up 
        else if (segment_input_element[i].getAttribute('id') == 'S-' + qu_id + '-pop-up-text') {
          val = ''

          qu_id = ''
        }
        ////  clicked_pop_up-multi
        else if (segment_input_element[i].getAttribute('id') == 'S-' + qu_id + '-pop-up-multi-clicked') {
          var multi_selected_elment = document.querySelectorAll('[id^="S-' + qu_id + '-pop-up-multi-clicked"]')

          for (var j = 0; j < multi_selected_elment.length; j++) {
            val += multi_selected_elment[j].innerHTML;
            if (j < multi_selected_elment.length - 1)
              val += ','
            multi_selected_elment[j].setAttribute("id", 'S-' + qu_id + '-pop-up-multi')
          }

        }

        // un clicked pop-up 
        else if (segment_input_element[i].getAttribute('id') == 'S-' + qu_id + '-pop-up-multi') {
          val = ''
          qu_id = ''
        }
        else if (segment_input_element[i].getAttribute('id') == 'S-' + qu_id + '-drop-text') {
          var drop = document.getElementById('S-' + qu_id + '-and-select-dropdown')
          val = segment_input_element[i].value + " " + drop.value

        } else if (segment_input_element[i].getAttribute('id') == 'S-' + question_id + '-and-select-dropdown') {
          val = ''
          qu_id = ''
        }
        // text , integer-ranage, dropdown 
        else {
          val = segment_input_element[i].value.trim()

        }

        segment_input += val;
        segment_qu_id += qu_id.trim()

        console.log('element_id:', element_id, 'val=', val, 'qu_id=', qu_id)

        if (i < segment_input_element.length - 1) {
          if (qu_id.trim() != '')
            segment_qu_id += ','
          if (val.trim() != '')
            segment_input += '/'
        }


      }

      for (var i = 0; i < segment_input_element.length; i++) {
        segment_input_element[i].removeAttribute("id")
        segment_input_element[i].disabled = true;
      }
      //id="S2-' + question_id + '-pop-up-text"

      var end_pop_elments = document.querySelectorAll('[id^="S2-"]');
      var end_clicked = null;
      if (end_pop_elments != null) {
        for (var j = 0; j < end_pop_elments.length; j++) {
          if (end_pop_elments[j].getAttribute('id').endsWith('clicked'))
            end_clicked = end_pop_elments[j]
        }
        if (end_clicked != null) {
          val = end_clicked.firstChild.innerHTML

          element_id = end_clicked.getAttribute('id')
          end_qu_id_index = element_id.indexOf('-', 3)
          qu_id = element_id.substring(3, end_qu_id_index)
          console.log('element_id:', element_id, 'val=', val, 'qu_id=', qu_id)
          segment_input += val
          segment_qu_id += qu_id
          for (var j = 0; j < end_pop_elments.length; j++) {
            end_pop_elments[j].removeAttribute("id")
            end_pop_elments[j].disabled = true;
          }


        }
      }
      //
      $('#segment').attr('id', 'postsegment');

    }


    else if (is_segment == false && is_sub_segment == 0 && input != 'meme') {

      var user_input_div = '<div class="outgoing-chats"><div class = "outgoing-chats-msg"><p id="user_chat-msg-p"><b>You</b><br>' + input + ' </p><span class="time">' + datetime + '</span></div><div class = "outgoing-chats-img"><i class="far fa-user" style="font-size:24px; color: #808080; margin-left:10px"></i></div></div>'

      $(user_input_div).insertBefore(".chat-animation")
      $(".msg-inbox").animate({ scrollTop: 1000000 }, 1000);
    }

    if (input.trim() == '')
      input = '?'

    if (segment_input.endsWith('/'))
      segment_input = segment_input.substring(0, segment_input.length - 1)

    if (segment_qu_id.endsWith(','))
      segment_qu_id = segment_qu_id.substring(0, segment_qu_id.length - 1)

    $.ajax({
      type: 'POST',
      url: '/get-response/',
      data: {

        'segment_input': segment_input,
        'segment_qu_id': segment_qu_id,
        'input': input
      },
      dataType: 'json',
      success: function (data) {

        //alert(data['message']['text'])
        //$("#chat-msg-p").text(data['message']['text'])

        var bot_reply_text = data['message']['text']
        var bot_reply_pop_ups = data['message']['pop_ups']
        var bot_reply_ask_date = data['message']['ask_date']
        var bot_reply_check_boxes = data['message']['check_boxes']
        var bot_reply_multiselect = data['message']['multiselect']
        var bot_reply_dropdown = data['message']['dropdown']

        //Code added by MM 
        var bot_reply_singleselect_positive = data['message']['singleselect_positive']
        var bot_reply_singleselect_negtive = data['message']['singleselectin_negative']
        var bot_reply_multiselect_positive = data['message']['multiselect_positive']
        var bot_reply_multiselect_negtive = data['message']['multiselect_negative']
        var bot_reply_singleselect_positive_negative = data['message']['singleselect_positive_negative']
        var bot_reply_multiselect_positive_negative = data['message']['multiselect_positive_negative']
        var bot_reply_singleselect_positive_negative_noa = data['message']['singleselect_positive_negative_noa']
        var bot_reply_multiselect_positive_negative_noa = data['message']['multiselect_positive_negative_noa']
        var bot_reply_integer_range_and_dropdown = data['message']['integer_range_and_dropdown']
        var bot_reply_text_and_dropdown = data['message']['text_and_dropdown']
        var bot_reply_integer_and_dropdown = data['message']['integer_and_dropdown']
        var bot_reply_integer_range = data['message']['integer_range']
        var bot_reply_segment = data['message']['segment']
        var bot_reply_text_segment = data['message']['text_segment']
        var bot_reply_is_sub_segment = data['message']['is_sub_segment']
        var bot_reply_ask_int = data['message']['ask_int']
        var bot_reply_ask_date_only = data['message']['ask_date_only']
        var bot_reply_ask_time_only = data['message']['ask_time_only']
        var text_length = data['message']['text_length']
        var intents_name = data['message']['intents_name']

        //console.log("intents_name", intents_name)
        autocomplete(document.getElementById("user-input"), intents_name);

        is_sub_segment = bot_reply_is_sub_segment
        question_id = data['message']['question_id']

        $('#user-input').attr("maxlength", text_length)
        is_segment = false
        ///

        ///

        var currentdate = new Date();

        var datetime = currentdate.getHours() + ":"
          + currentdate.getMinutes()
        if (bot_reply_check_boxes != null) {

          var check_boxes_div = '<div class ="check_boxes_div">'

          var button_div = ''
          if (is_sub_segment == 1) {
            button_div = ''
            for (var key in bot_reply_check_boxes) {
              var check_box = '<input type="checkbox" class="checkboxes-input" id=S-' + question_id + '-' + bot_reply_check_boxes[key] + '" name= "S-' + question_id + '-checkboxes-input" value=' + bot_reply_check_boxes[key] + '>' +
                '<label class="checkboxes-label" for="S-' + question_id + '-' + bot_reply_check_boxes[key] + '" >' + bot_reply_check_boxes[key] + '</label><br>'

              check_boxes_div = check_boxes_div.concat(check_box)
            }
          }
          else {
            for (var key in bot_reply_check_boxes) {
              var check_box = '<input type="checkbox" class="checkboxes-input" id=' + bot_reply_check_boxes[key] + '" name= "checkboxes-input" value=' + bot_reply_check_boxes[key] + '>' +
                '<label class="checkboxes-label" for="' + bot_reply_check_boxes[key] + '" >' + bot_reply_check_boxes[key] + '</label><br>'

              check_boxes_div = check_boxes_div.concat(check_box)
            }
            button_div = '<button class="btn btn-primary" id="submit-checkboxes-btn">Submit</button>' +
              '<span class="time">' + datetime + '</span>'
          }
          check_boxes_div = check_boxes_div.concat('</div>')
          var reply_div =
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            check_boxes_div +
            button_div +

            '</div>' +
            '</div>'

          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")
          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();
          }

        }

        if (bot_reply_pop_ups != null) {

          var regex = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/gi;
          var res = bot_reply_text.match(regex)

          var pop_up_divs = '<div class="pop-ups">'
          for (var key in bot_reply_pop_ups) {
            var pop_up_div = '<div class = "pop-up"><p class="pop-up-text">' + bot_reply_pop_ups[key] + '</p></div>'
            if (is_sub_segment == 1)
              pop_up_div = '<div class = "pop-up" id="S-' + question_id + '-pop-up-text" ><p class="pop-up-text">' + bot_reply_pop_ups[key] + '</p></div>'
            else if (is_sub_segment == 2)
              pop_up_div = '<div class = "pop-up" id="S2-' + question_id + '-pop-up-text" ><p  class="pop-up-text">' + bot_reply_pop_ups[key] + '</p></div>'

            pop_up_divs = pop_up_divs.concat(pop_up_div)
          }
          pop_up_divs = pop_up_divs.concat('</div>')

          if (res != null) {
            var res2 = String(res)

            var text_data = bot_reply_text.replace(res, "")
            var lastChar = res2[res2.length - 1];
            if (lastChar == '.') {
              res2 = res2.slice(0, -1)
            }

            var reply_div = '<div class="received-chats" ><div class = "received-chats-img"><i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i></div><div class = "received-msg"><div class = "received-msg-inbox"><p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + text_data + '</p><p id = "anchor-tag"><a id="anchor-tag-a" href=' + res2 + ' target="_blank">' + res2 + '</a></p></div>' + pop_up_divs
          }
          else {
            var reply_div = '<div class="received-chats" ><div class = "received-chats-img"><i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i></div><div class = "received-msg"><div class = "received-msg-inbox"><p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p></div>' + pop_up_divs
          }


          if (is_sub_segment == 0) {
            reply_div += '<div class="time">' + datetime + '</div></div></div>'
          }
          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")



          if (is_sub_segment == 2) {
            reply_div += '<div class="submit-multiselect-div"><button class="btn btn-primary" id="submit-singleselect">Submit</button>' +
              '<span class="time">' + datetime + '</span></div>'
          }

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();

          }




        }
        //added by MM
        if (bot_reply_singleselect_positive != null) {

          var regex = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/gi;
          var res = bot_reply_text.match(regex)

          var pop_up_divs = '<div class="pop-ups">'
          for (var key in bot_reply_singleselect_positive) {
            var pop_up_div = '<div class = "pop-up"><p class="pop-up-text">' + bot_reply_singleselect_positive[key] + '</p></div>'
            if (is_sub_segment == 1)
              pop_up_div = '<div class = "pop-up" id="S-' + question_id + '-pop-up-text" ><p class="pop-up-text">' + bot_reply_singleselect_positive[key] + '</p></div>'
            else if (is_sub_segment == 2)
              pop_up_div = '<div class = "pop-up" id="S2-' + question_id + '-pop-up-text" ><p class="pop-up-text">' + bot_reply_singleselect_positive[key] + '</p></div>'

            pop_up_divs = pop_up_divs.concat(pop_up_div)
          }
          pop_up_divs = pop_up_divs.concat('</div>')

          if (res != null) {
            var res2 = String(res)

            var text_data = bot_reply_text.replace(res, "")
            var lastChar = res2[res2.length - 1];
            if (lastChar == '.') {
              res2 = res2.slice(0, -1)
            }

            var reply_div = '<div class="received-chats" ><div class = "received-chats-img"><i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i></div><div class = "received-msg"><div class = "received-msg-inbox"><p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + text_data + '</p><p id = "anchor-tag"><a id="anchor-tag-a" href=' + res2 + ' target="_blank">' + res2 + '</a></p></div>' + pop_up_divs
          }
          else {
            var reply_div = '<div class="received-chats" ><div class = "received-chats-img"><i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i></div><div class = "received-msg"><div class = "received-msg-inbox"><p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p></div>' + pop_up_divs
          }

          if (is_sub_segment == 0)
            reply_div += '<div class="time">' + datetime + '</div></div></div>'
          else
            reply_div += '</div></div>'

          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")

          if (is_sub_segment == 2) {
            reply_div += '<div class="submit-multiselect-div"><button class="btn btn-primary" id="submit-singleselect">Submit</button>' +
              '<span class="time">' + datetime + '</span></div>'
          }

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();

          }

        }

        if (bot_reply_singleselect_negtive != null) {

          var regex = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/gi;
          var res = bot_reply_text.match(regex)

          var pop_up_divs = '<div class="pop-ups">'
          for (var key in bot_reply_singleselect_negtive) {
            var pop_up_div = '<div class = "pop-up"><p class="pop-up-text">' + bot_reply_singleselect_negtive[key] + '</p></div>'
            if (is_sub_segment == 1)
              pop_up_div = '<div class = "pop-up" id="S-' + question_id + '-pop-up-text" ><p class="pop-up-text">' + bot_reply_singleselect_negtive[key] + '</p></div>'
            else if (is_sub_segment == 2)
              pop_up_div = '<div class = "pop-up" id="S2-' + question_id + '-pop-up-text" ><p class="pop-up-text">' + bot_reply_singleselect_negtive[key] + '</p></div>'

            pop_up_divs = pop_up_divs.concat(pop_up_div)
          }
          pop_up_divs = pop_up_divs.concat('</div>')

          if (res != null) {
            var res2 = String(res)

            var text_data = bot_reply_text.replace(res, "")
            var lastChar = res2[res2.length - 1];
            if (lastChar == '.') {
              res2 = res2.slice(0, -1)
            }

            var reply_div = '<div class="received-chats" ><div class = "received-chats-img"><i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i></div><div class = "received-msg"><div class = "received-msg-inbox"><p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + text_data + '</p><p id = "anchor-tag"><a id="anchor-tag-a" href=' + res2 + ' target="_blank">' + res2 + '</a></p></div>'
          }
          else {
            var reply_div = '<div class="received-chats" ><div class = "received-chats-img"><i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i></div><div class = "received-msg"><div class = "received-msg-inbox"><p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p></div>' + pop_up_divs
          }
          if (is_sub_segment == 0)
            reply_div += '<div class="time">' + datetime + '</div></div></div>'
          else
            reply_div += '</div></div>'

          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")

          if (is_sub_segment == 2) {
            reply_div += '<div class="submit-multiselect-div"><button class="btn btn-primary" id="submit-singleselect">Submit</button>' +
              '<span class="time">' + datetime + '</span></div>'
          }

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();
          }

        }

        if (bot_reply_singleselect_positive_negative != null) {

          var regex = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/gi;
          var res = bot_reply_text.match(regex)

          var pop_up_divs = '<div class="pop-ups">'
          for (var key in bot_reply_singleselect_positive_negative) {
            var pop_up_div = '<div class = "pop-up"><p class="pop-up-text">' + bot_reply_singleselect_positive_negative[key] + '</p></div>'
            if (is_sub_segment == 1)
              pop_up_div = '<div class = "pop-up" id="S-' + question_id + '-pop-up-text" ><p class="pop-up-text">' + bot_reply_singleselect_positive_negative[key] + '</p></div>'
            else if (is_sub_segment == 2)
              pop_up_div = '<div class = "pop-up" id="S2-' + question_id + '-pop-up-text" ><p class="pop-up-text">' + bot_reply_singleselect_positive_negative[key] + '</p></div>'

            pop_up_divs = pop_up_divs.concat(pop_up_div)
          }
          pop_up_divs = pop_up_divs.concat('</div>')

          if (res != null) {
            var res2 = String(res)

            var text_data = bot_reply_text.replace(res, "")
            var lastChar = res2[res2.length - 1];
            if (lastChar == '.') {
              res2 = res2.slice(0, -1)
            }

            var reply_div = '<div class="received-chats" ><div class = "received-chats-img"><i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i></div><div class = "received-msg"><div class = "received-msg-inbox"><p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + text_data + '</p><p id = "anchor-tag"><a id="anchor-tag-a" href=' + res2 + ' target="_blank">' + res2 + '</a></p></div>'
          }
          else {
            var reply_div = '<div class="received-chats" ><div class = "received-chats-img"><i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i></div><div class = "received-msg"><div class = "received-msg-inbox"><p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p></div>' + pop_up_divs
          }

          if (is_sub_segment == 0)
            reply_div += '<div class="time">' + datetime + '</div></div></div>'
          else
            reply_div += '</div></div>'

          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")

          if (is_sub_segment == 2) {
            reply_div += '<div class="submit-multiselect-div"><button class="btn btn-primary" id="submit-singleselect">Submit</button>' +
              '<span class="time">' + datetime + '</span></div>'
          }

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();

          }

        }

        if (bot_reply_singleselect_positive_negative_noa != null) {

          var regex = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/gi;
          var res = bot_reply_text.match(regex)

          var pop_up_divs = '<div class="pop-ups">'
          for (var key in bot_reply_singleselect_positive_negative_noa) {
            var pop_up_div = '<div class = "pop-up"><p class="pop-up-text">' + bot_reply_singleselect_positive_negative_noa[key] + '</p></div>'
            if (is_sub_segment == 1)
              pop_up_div = '<div class = "pop-up" id="S-' + question_id + '-pop-up-text" ><p class="pop-up-text">' + bot_reply_singleselect_positive_negative_noa[key] + '</p></div>'
            else if (is_sub_segment == 2)
              pop_up_div = '<div class = "pop-up" id="S2-' + question_id + '-pop-up-text" ><p class="pop-up-text">' + bot_reply_singleselect_positive_negative_noa[key] + '</p></div>'

            pop_up_divs = pop_up_divs.concat(pop_up_div)
          }
          pop_up_divs = pop_up_divs.concat('</div>')

          if (res != null) {
            var res2 = String(res)

            var text_data = bot_reply_text.replace(res, "")
            var lastChar = res2[res2.length - 1];
            if (lastChar == '.') {
              res2 = res2.slice(0, -1)
            }

            var reply_div = '<div class="received-chats" ><div class = "received-chats-img"><i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i></div><div class = "received-msg"><div class = "received-msg-inbox"><p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + text_data + '</p><p id = "anchor-tag"><a id="anchor-tag-a" href=' + res2 + ' target="_blank">' + res2 + '</a></p></div>' + pop_up_divs
          }
          else {
            var reply_div = '<div class="received-chats" ><div class = "received-chats-img"><i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i></div><div class = "received-msg"><div class = "received-msg-inbox"><p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p></div>' + pop_up_divs
          }

          if (is_sub_segment == 0)
            reply_div += '<div class="time">' + datetime + '</div></div></div>'
          else
            reply_div += '</div></div>'

          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")
          if (is_sub_segment == 2) {
            reply_div += '<div class="submit-multiselect-div"><button class="btn btn-primary" id="submit-singleselect">Submit</button>' +
              '<span class="time">' + datetime + '</span></div>'
          }

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();

          }

        }

        if (bot_reply_multiselect != null) {
          var pop_up_multiselect_div = '<div class="pop_up_mulitselect">'
          for (var key in bot_reply_multiselect) {

            var pop_up_multi_div = '<div class = "pop-up_multi_div"><p class="pop-up-text-multi">' + bot_reply_multiselect[key] + '</p></div>'

            if (is_sub_segment == 1)
              pop_up_multi_div = '<div class = "pop-up_multi_div"><p  id="S-' + question_id + '-pop-up-multi" class="pop-up-text-multi">' + bot_reply_multiselect[key] + '</p></div>'

            pop_up_multiselect_div = pop_up_multiselect_div.concat(pop_up_multi_div)
          }
          pop_up_multiselect_div = pop_up_multiselect_div.concat('</div>')

          var button_div = ''
          if (is_sub_segment == 1) {
            button_div = ''
          }
          else {
            button_div = '<div class="submit-multiselect-div"><button class="btn btn-primary" id="submit-multiselect">Submit</button>' +
              '<span class="time">' + datetime + '</span></div>'
          }

          var reply_div = '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            pop_up_multiselect_div +
            button_div +

            '</div>' +
            '</div>'
          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();

          }
        }
        // Added by MM
        if (bot_reply_multiselect_positive != null) {
          var pop_up_multiselect_div = '<div class="pop_up_mulitselect">'
          for (var key in bot_reply_multiselect_positive) {


            var pop_up_multi_div = '<div class = "pop-up_multi_div"><p class="pop-up-text-multi"   id="S-' + question_id + '-pop-up-text-multi">' + bot_reply_multiselect_positive[key] + '</p></div>'
            if (is_sub_segment == 1)
              pop_up_multi_div = '<div class = "pop-up_multi_div"><p  id="S-' + question_id + '-pop-up-multi" class="pop-up-text-multi">' + bot_reply_multiselect[key] + '</p></div>'

            pop_up_multiselect_div = pop_up_multiselect_div.concat(pop_up_multi_div)
          }
          pop_up_multiselect_div = pop_up_multiselect_div.concat('</div>')

          var button_div = ''
          if (is_sub_segment == 1) {
            button_div = ''
          }
          else {
            button_div = '<div class="submit-multiselect-div"><button class="btn btn-primary" id="submit-multiselect">Submit</button>' +
              '<span class="time">' + datetime + '</span></div>'
          }



          var reply_div = '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            pop_up_multiselect_div +
            button_div +

            '</div>' +
            '</div>'
          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")
          console.log(reply_div)
          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();

          }
        }
        if (bot_reply_multiselect_negtive != null) {
          var pop_up_multiselect_div = '<div class="pop_up_mulitselect">'
          for (var key in bot_reply_multiselect_negtive) {

            var pop_up_multi_div = '<div class = "pop-up_multi_div"><p class="pop-up-text-multi">' + bot_reply_multiselect_negtive[key] + '</p></div>'
            if (is_sub_segment == 1)
              pop_up_multi_div = '<div class = "pop-up_multi_div"><p  id="S-' + question_id + '-pop-up-multi" class="pop-up-text-multi">' + bot_reply_multiselect[key] + '</p></div>'

            pop_up_multiselect_div = pop_up_multiselect_div.concat(pop_up_multi_div)
          }
          pop_up_multiselect_div = pop_up_multiselect_div.concat('</div>')

          var button_div = ''
          if (is_sub_segment == 1) {
            button_div = ''
          }
          else {
            button_div = '<div class="submit-multiselect-div"><button class="btn btn-primary" id="submit-multiselect">Submit</button>' +
              '<span class="time">' + datetime + '</span></div>'

          }

          var reply_div =
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            pop_up_multiselect_div +
            button_div +

            '</div>' +
            '</div>'
          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();

          }
        }

        if (bot_reply_multiselect_positive_negative != null) {
          var pop_up_multiselect_div = '<div class="pop_up_mulitselect">'
          for (var key in bot_reply_multiselect_positive_negative) {

            var pop_up_multi_div = '<div class = "pop-up_multi_div"><p class="pop-up-text-multi">' + bot_reply_multiselect_positive_negative[key] + '</p></div>'
            if (is_sub_segment == 1)
              pop_up_multi_div = '<div class = "pop-up_multi_div"><p  id="S-' + question_id + '-pop-up-multi" class="pop-up-text-multi">' + bot_reply_multiselect[key] + '</p></div>'

            pop_up_multiselect_div = pop_up_multiselect_div.concat(pop_up_multi_div)
          }
          pop_up_multiselect_div = pop_up_multiselect_div.concat('</div>')


          var reply_div =
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            pop_up_multiselect_div +
            '<div class="submit-multiselect-div"><button class="btn btn-primary" id="submit-multiselect">Submit</button></div>' +
            '<span class="time">' + datetime + '</span>' +
            '</div>' +
            '</div>'
          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")
          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();

          }
        }

        if (bot_reply_multiselect_positive_negative_noa != null) {
          var pop_up_multiselect_div = '<div class="pop_up_mulitselect">'
          for (var key in bot_reply_multiselect_positive_negative_noa) {

            var pop_up_multi_div = '<div class = "pop-up_multi_div"><p class="pop-up-text-multi">' + bot_reply_multiselect_positive_negative_noa[key] + '</p></div>'
            if (is_sub_segment == 1)
              pop_up_multi_div = '<div class = "pop-up_multi_div"><p  id="S-' + question_id + '-pop-up-multi" class="pop-up-text-multi">' + bot_reply_multiselect[key] + '</p></div>'

            pop_up_multiselect_div = pop_up_multiselect_div.concat(pop_up_multi_div)
          }
          pop_up_multiselect_div = pop_up_multiselect_div.concat('</div>')
          console.log(pop_up_multiselect_div)

          var reply_div =
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            pop_up_multiselect_div +
            '<div class="submit-multiselect-div"><button class="btn btn-primary" id="submit-multiselect">Submit</button></div>' +
            '<span class="time">' + datetime + '</span>' +
            '</div>' +
            '</div>'
          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();

          }
        }

        // End MM  

        if (bot_reply_ask_date != false) {

          var date_div = '<div class="ask-date-div">'
          var button_div = ''
          if (is_sub_segment == 1) {
            button_div = ''
            date_div = '<input id="S-' + question_id + '-datetimepicker" class="datetimepicker-cls" type="text" >' +
              '</div>'
          }
          else {
            date_div = '<input id="datetimepicker" class="datetimepicker-cls" type="text" >' +
              '</div>'
            button_div = '<button class="btn btn-primary" id="submit-datetime-btn">Submit</button>' +
              '<span class="time">' + datetime + '</span>'
          }
          var reply_div =
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            date_div +
            button_div +

            '</div>' +
            '</div>'

          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();
          }
        }
        else if (bot_reply_ask_date_only != false) {

          var date_div = '<div class="ask-date-div">'
          var button_div = ''
          if (is_sub_segment == 1) {
            button_div = ''
            date_div = '<input id="S-' + question_id + '-datetimepicker" class="datetimepicker-cls" type="date" >' +
              '</div>'
          }
          else {
            date_div = '<input id="datetimepicker" class="datetimepicker-cls" type="date" >' +
              '</div>'
            button_div = '<button class="btn btn-primary" id="submit-datetime-btn">Submit</button>' +
              '<span class="time">' + datetime + '</span>'
          }
          var reply_div =
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            date_div +
            button_div +

            '</div>' +
            '</div>'

          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();
          }
        }

        else if (bot_reply_ask_time_only != false) {

          var date_div = '<div class="ask-date-div">'
          var button_div = ''
          if (is_sub_segment == 1) {
            button_div = ''
            date_div = '<input id="S-' + question_id + '-datetimepicker" class="datetimepicker-cls" type="time" >' +
              '</div>'
          }
          else {
            date_div = '<input id="datetimepicker" class="datetimepicker-cls" type="time" >' +
              '</div>'
            button_div = '<button class="btn btn-primary" id="submit-datetime-btn">Submit</button>' +
              '<span class="time">' + datetime + '</span>'
          }
          var reply_div =
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            date_div +
            button_div +

            '</div>' +
            '</div>'
          console.log("date_div: ", date_div)
          console.log("button_div:", button_div)
          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();
          }
        }

        // added by MM July 23
        else if (bot_reply_segment != false) {
          var reply_div = '<div id="segment">' +
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i></div>' +
            '<div class = "received-msg" style="width: 80%;">' +
            '<div class = "received-msg-inbox" style="width: 100%;" >' +
            '<p id = "bot_chat-msg-p" style="width: 100%;"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '</div>' +
            '</div>'


          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")
          ///
          $("#user-input").val("-")
          is_segment = true

          document.getElementById("send-btn").click();

        }
        // added by MM July 23
        else if (bot_reply_text_segment != false) {

          var text_div = '<div class="dropdown-div">' +
            '<input id="text-integer" class="text-integer" type="text">'

          var button_div = ''
          if (is_sub_segment == 1) {
            button_div = ''
            text_div = '<input id="S-' + question_id + '-text-integer" class="datetimepicker-cls" type="text">'

          }

          else
            button_div = ' <button class="btn btn-primary" id="submit-integer">Submit</button> ' +
              '<span class="time">' + datetime + '</span>'


          var reply_div =
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            text_div
            + button_div +

            '</div>' +
            '</div>'
          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();
          }

        }
        else if (bot_reply_ask_int != false) {

          var text_div = '<div class="dropdown-div">' +
            '<input id="text-integer" class="text-integer" type="number">'

          var button_div = ''
          if (is_sub_segment == 1) {
            button_div = ''
            text_div = '<input id="S-' + question_id + '-text-integer" class="datetimepicker-cls" type="number">'

          }

          else
            button_div = ' <button class="btn btn-primary" id="submit-integer">Submit</button> ' +
              '<span class="time">' + datetime + '</span>'


          var reply_div =
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            text_div
            + button_div +

            '</div>' +
            '</div>'
          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();
          }

        }

        // added on July 22 b MM to implement the integer range question type
        else if (bot_reply_integer_range != null) {
          var range = bot_reply_integer_range
          var range_min = range.substring(range.indexOf("[") + 1, range.indexOf("/")).trim()
          var range_max = range.substring(range.indexOf("/") + 1, range.indexOf("]")).trim()

          var integer_div = '<div class="dropdown-div">' +
            '<input id="text-integer" class="text-integer" type="number" min="' + range_min + '" max="' +
            range_max + '" value="' + range_min + '">'
          var reply_div = ''
          var button_div = ''
          if (is_sub_segment == 1) {
            button_div = ''
            integer_div = '<div class="dropdown-div" style="margin : 0px 0px 0px 10px;   padding: 0px 0px 0px 10px;">' +
              '<input id="S-' + question_id + '-text-integer" class="text-integer" type="number" min="' + range_min + '" max="' +
              range_max + '" value="' + range_min + '">'
            reply_div += '<p id = "bot_chat-msg-p" style="padding: 0px; margin: 20px 0px 0px 0px;">' + bot_reply_text + '</p>'
          }
          else if (is_sub_segment == 2) {
            integer_div = '<div class="dropdown-div" style="margin : 0px 0px 0px 10px;   padding: 0px 0px 0px 10px;">' +
              '<input id="text-integer" class="text-integer" type="number" min="' + range_min + '" max="' +
              range_max + '" value="' + range_min + '"></div>'
            button_div = '<div class="dropdown-div"   style="margin : 0px 0px 0px 10px;   padding: 0px 0px 0px 10px;"> <button class="btn btn-primary" id="submit-integer">Submit</button>' +
              '<span class="time" style=" margin: 30px 0px 0px 5px;">' + datetime + '</span></div></div>'
            reply_div += '<p id = "bot_chat-msg-p"  style="padding: 0px; margin: 20px 0px 0px 0px;">' + bot_reply_text + '</p>'

          }
          else {
            button_div = ' <button class="btn btn-primary" id="submit-integer">Submit</button> ' +
              '<span class="time">' + datetime + '</span></div></div>'
            reply_div +=
              '<div class="received-chats" >' +
              '<div class = "received-chats-img">' +
              '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
              '</div>' +
              '<div class = "received-msg">' +
              '<div class = "received-msg-inbox">' +
              '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
              '</div>'
          }

          reply_div += integer_div + button_div



          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")
          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();
          }

        }

        else if (bot_reply_dropdown != null) {
          var dropdown_div = '<div class="dropdown-div">' +
            '<select name="select-dropdown" id="select-dropdown" class="select-dropdown-class">'

          var button_div = ''
          if (is_sub_segment == 1) {
            button_div = ''
            var dropdown_div = '<div class="dropdown-div">' +
              '<select name="select-dropdown" id="S-' + question_id + '-and-select-dropdown" class="select-dropdown-class">'

          }

          else
            button_div = '<button class="btn btn-primary" id="submit-dropdown" > Submit </button>'

          for (var option in bot_reply_dropdown) {
            var select_option = '<option value=' + bot_reply_dropdown[option] + '>' + bot_reply_dropdown[option] + '</option>'
            dropdown_div = dropdown_div.concat(select_option)
          }
          dropdown_div = dropdown_div.concat('</select>')
          dropdown_div = dropdown_div.concat('</div>')

          var reply_div =
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            dropdown_div +
            button_div +

            '</div>' +
            '</div>'

          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")


          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();
          }
        }

        // added by MM July 15,2021

        else if (bot_reply_integer_range_and_dropdown != null) {

          var button_div = ''
          var dropdown_div = '<select name="select-dropdown" id="select-dropdown" class="select-dropdown-class">'
          if (is_sub_segment == 1) {
            dropdown_div = '<select name="select-dropdown" id="S-' + question_id + '-and-select-dropdown" class="select-dropdown-class">'
          }
          else {
            button_div = '<button class="btn btn-primary" id="submit-text-dropdown">Submit</button>' +
              '<span class="time">' + datetime + '</span>'
          }
          for (var option in bot_reply_integer_range_and_dropdown) {
            var all_option = bot_reply_integer_range_and_dropdown[option]
            var option_text = all_option.substring(0, all_option.indexOf("["))
            range_min_list.push(all_option.substring(all_option.indexOf("[") + 1, all_option.indexOf("/")).trim())
            range_max_list.push(all_option.substring(all_option.indexOf("/") + 1, all_option.indexOf("]")).trim())
            var select_option = '<option value=' + option_text + '>' + option_text + '</option>'
            dropdown_div = dropdown_div.concat(select_option)
          }
          dropdown_div = dropdown_div.concat('</select>')
          dropdown_div = dropdown_div.concat('</div>')


          if (is_sub_segment == 1) {
            dropdown_div = '<div class="dropdown-div">' +
              '<input id="S-' + question_id + '-drop-text" class="text-dropdown" type="number" min="' + range_min_list[0] + '" max="' +
              range_max_list[0] + '" value="' + range_min_list[0] + '">' + dropdown_div

          }
          else {
            dropdown_div = '<div class="dropdown-div">' +
              '<input id="drop-text" class="text-dropdown" type="number" min="' + range_min_list[0] + '" max="' +
              range_max_list[0] + '" value="' + range_min_list[0] + '" >' + dropdown_div

          }

          var reply_div =
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            dropdown_div +
            button_div +

            '</div>' +
            '</div>'

          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")
          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();
          }

        }

        else if (bot_reply_text_and_dropdown != null) {
          var dropdown_div = '<div class="dropdown-div">' +
            '<input id="drop-text" class="text-dropdown" type="text " >' +
            '<select name="select-dropdown" id="select-dropdown" class="select-dropdown-class">'
          var button_div = ''

          if (is_sub_segment == 1) {

            dropdown_div = '<div class="dropdown-div">' +
              '<input id="S-' + question_id + '-drop-text" class="text-dropdown" type="text " >' +
              '<select name="select-dropdown" id="S-' + question_id + '-and-select-dropdown" class="select-dropdown-class">'
          }
          else
            button_div = '<button class="btn btn-primary" id="submit-text-dropdown">Submit</button>' +
              '<span class="time">' + datetime + '</span>'

          for (var option in bot_reply_text_and_dropdown) {
            var select_option = '<option value=' + bot_reply_text_and_dropdown[option] + '>' + bot_reply_text_and_dropdown[option] + '</option>'
            if (is_sub_segment == 1)
              select_option = '<option  value=' + bot_reply_text_and_dropdown[option] + '>' + bot_reply_text_and_dropdown[option] + '</option>'

            dropdown_div = dropdown_div.concat(select_option)

          }
          dropdown_div = dropdown_div.concat('</select>')

          dropdown_div = dropdown_div.concat('</div>')



          var reply_div =
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            dropdown_div +
            button_div +

            '</div>' +
            '</div>'

          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();
          }

        }

        else if (bot_reply_integer_and_dropdown != null) {
          var dropdown_div = '<div class="dropdown-div">' +
            '<input id="drop-text" class="text-dropdown" type="number" >' +
            '<select name="select-dropdown" id="select-dropdown" class="select-dropdown-class">'
          var button_div = ''
          if (is_sub_segment == 1) {
            dropdown_div = '<div class="dropdown-div">' +
              '<input id="S-' + question_id + '-drop-text" class="text-dropdown" type="number" >' +
              '<select name="select-dropdown" id="S-' + question_id + '-and-select-dropdown" class="select-dropdown-class">'
          }
          else {
            button_div = '<button class="btn btn-primary" id="submit-text-dropdown">Submit</button>' +
              '<span class="time">' + datetime + '</span>'
          }

          for (var option in bot_reply_integer_and_dropdown) {
            var select_option = '<option value=' + bot_reply_integer_and_dropdown[option] + '>' + bot_reply_integer_and_dropdown[option] + '</option>'
            dropdown_div = dropdown_div.concat(select_option)
          }
          dropdown_div = dropdown_div.concat('</select>')
          dropdown_div = dropdown_div.concat('</div>')

          var reply_div =
            '<div class="received-chats" >' +
            '<div class = "received-chats-img">' +
            '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i>' +
            '</div>' +
            '<div class = "received-msg">' +
            '<div class = "received-msg-inbox">' +
            '<p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p>' +
            '<div>' +
            dropdown_div +
            button_div +

            '</div>' +
            '</div>'

          $("#user-input").attr('disabled', 'disabled')
          $("#send-btn").css("pointer-events", "none")

          if (is_sub_segment == 1) {
            $("#user-input").val("?")
            is_segment = true
            document.getElementById("send-btn").click();
          }



        }

        if ((bot_reply_pop_ups == null) && (bot_reply_check_boxes == null) && (bot_reply_ask_date == false)
          && (bot_reply_multiselect == null) && (bot_reply_dropdown == null)
          && (bot_reply_multiselect_negtive == null) && (bot_reply_multiselect_positive == null)
          && (bot_reply_singleselect_negtive == null) && (bot_reply_singleselect_positive == null)
          && (bot_reply_multiselect_positive_negative == null) && (bot_reply_singleselect_positive_negative == null)
          && (bot_reply_multiselect_positive_negative_noa == null) && (bot_reply_singleselect_positive_negative_noa == null)
          && (bot_reply_integer_range_and_dropdown == null) && (bot_reply_text_and_dropdown == null) && (bot_reply_integer_and_dropdown == null)
          && (bot_reply_integer_range == null) && (bot_reply_segment == false) && (bot_reply_text_segment == false) &&
          (bot_reply_ask_date_only == false) && (bot_reply_ask_time_only == false) && (bot_reply_ask_int == false)) {

          var regex = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/gi;
          var res = bot_reply_text.match(regex)

          if (res != null) {
            var reply_div = ""

            var text_data = bot_reply_text.replace(res, "")

            reply_div = '<div class="received-chats" ><div class = "received-chats-img">' +
              '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i></div>' +
              '<div class = "received-msg"><div class = "received-msg-inbox"><p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + text_data + '</p><p id = "anchor-tag"><a href=' + res + ' target="_blank">' + res + '</a></p></div>' +
              '<span class="time">' + datetime + '</span></div></div>'


          }
          else {
            var reply_div = ""

            reply_div = '<div class="received-chats" ><div class = "received-chats-img">' +
              '<i class="fas fa-briefcase-medical" style="font-size:24px; color: #0063cc"></i></div>' +
              '<div class = "received-msg"><div class = "received-msg-inbox"><p id = "bot_chat-msg-p"><b>Brantford Pediatrics</b><br>' + bot_reply_text + '</p></div>' +
              '<span class="time">' + datetime + '</span></div></div>'


          }


        }

        $(".chat-animation").hide()
        //console.log("reply_div: " + reply_div)
        if (is_sub_segment > 0) {

          $("#segment").append(reply_div);
          reply_div = $(".segment").html()

        }

        $(reply_div).insertBefore(".chat-animation")
        $(".msg-inbox").animate({ scrollTop: 1000000 }, 1000);

        //$(".msg-page").animate({ scrollTop: $(".msg-page")[0].scrollHeight}, 100);

      },
      error: function (xhr, status, error) {
        alert("error")
        console.log(" xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: " + error);

      }

    })
  });
})