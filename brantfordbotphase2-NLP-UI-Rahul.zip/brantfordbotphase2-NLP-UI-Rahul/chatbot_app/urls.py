from django.urls import path, include
from . import views

# Chatbot url's are present here


urlpatterns = [
	path('bot/', views.bot_api, name='bot'),
	path('get-response/', views.get_response),
	path('end-session/', views.end_session),
	path('start-chat/', views.create_session),
	
]