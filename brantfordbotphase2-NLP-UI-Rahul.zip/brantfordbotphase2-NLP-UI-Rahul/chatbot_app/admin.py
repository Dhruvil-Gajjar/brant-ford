from django.contrib import admin


# To create the models active