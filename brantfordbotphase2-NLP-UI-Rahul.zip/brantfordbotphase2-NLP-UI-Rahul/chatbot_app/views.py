from visito import settings
import json
import time
from datetime import datetime, timedelta

from dateutil import relativedelta
from django.core.mail import EmailMultiAlternatives
from django.http import HttpResponse
from django.shortcuts import render
from django.template.loader import render_to_string
from django.utils import timezone
from django.utils.html import strip_tags
from django.views.decorators.csrf import csrf_exempt

from nlp.models import ChatInfo, Intent, Question, Response, GroupQuestion, FollowUpQuestion, GroupInfo
from account.tasks import send_email_visito
# Create your views here.
# Maps inquiry messages to intents in database
inquiry_dict = {
    # 'appointment': 'appointment',
    # 'prescription': 'prescription',
    # 'front desk': 'front_desk',
    # 'connect with doctor': 'connect_with_doctor',
    # 'results': 'results',
    # 'other': 'other'
    # ,'test': 'test'
}


def bot_api(request, template_name="chatbot_app/test2.html"):
    context = {'title': 'Chatbot Version 2.0'}
    return render(request, template_name, context)


@csrf_exempt
def create_session(request):
    response = {'status': None}
    if request.method == 'POST':

        request.session['email_id'] = request.POST.get('email')
        request.session['name'] = request.POST.get('fname')
        request.session['date_of_birth'] = request.POST.get('dob')
        request.session['age'] = calculate_age(datetime.strptime(
            request.session['date_of_birth'], '%Y-%m-%d'))

        request.session['continue_asked'] = False
        request.session['user_info_complete'] = False
        request.session['first_visit'] = False
        request.session['registration_form'] = False
        request.session['clinical_form'] = False
        request.session['form_type'] = ''
        request.session['chat_id'] = 0
        request.session['follow_up_check'] = False

        request.session['follow_up_asked'] = False
        request.session['group_id'] = None
        request.session['group_for_each'] = ""
        request.session['group_question_list'] = {
            "qu_id": [], "for_each": [], "no": []}
        request.session['question_asked'] = []
        request.session['group_item_no'] = []
        request.session['answer_received'] = []
        request.session['is_appointment'] = False
        request.session['ask_associated_symptoms'] = False
        request.session['accept_intent'] = False
        request.session['no_question_intent'] = []
        request.session['miscommunication_counter'] = 0

        response['message'] = {'session': request.session['email_id']}
        response['status'] = 'ok'
    else:
        response['error'] = 'no post data found'
    return HttpResponse(
        json.dumps(response),
        content_type="application/json"
    )


# To email the chat request to the reciepent
def email_new_chat(chat_id, name, email_id):
    context = {"chat_id": chat_id, "name": name, "email_id": email_id}
    html_content = render_to_string('chatbot_app/mail_template.html', context)
    text_message = strip_tags(html_content)

    # email = EmailMultiAlternatives(
    #     ' A new chat from ' + name,
    #     text_message,
    #     settings.EMAIL_HOST_USER,
    #     [email_id]
    # )
    # email.attach_alternative(html_content, "text/html")
    # email.send()

    # TODO DHRUVIL EMAIL
    mail_subject = ' A new chat from ' + name
    send_email_visito.delay(
        mail_subject=mail_subject,
        mail_body=text_message,
        mail_attachment=html_content,
        to_email=email_id
    )


@csrf_exempt
def end_session(request):
    response = {'status': None}
    if request.method == 'POST':
        response['status'] = 'ok'

        if 'email_id' in request.session:
            email_new_chat(
                request.session['chat_id'], request.session['name'], request.session['email_id'])
            request.session.flush()

        else:
            response['error'] = 'no session found'
    else:
        response['error'] = 'no post data found'

    return HttpResponse(
        json.dumps(response),
        content_type="application/json"
    )

# response of the chat goes here into the model

@csrf_exempt
def get_response(request):
    response = {'status': None}

    if request.method == 'POST':
        # Set defaults for question type pop up options
        pop_ups = None
        ask_date = False
        ask_int = False
        ask_date_only = False
        ask_time_only = False
        check_boxes = None
        multiselect = None
        dropdown = None
        multiselect_positive = None
        multiselect_negative = None
        singleselect_positive = None
        singleselect_negative = None
        multiselect_positive_negative = None
        singleselect_positive_negative = None
        multiselect_positive_negative_noa = None
        singleselect_positive_negative_noa = None
        integer_range_and_dropdown = None
        text_and_dropdown = None
        integer_and_dropdown = None
        integer_range = None
        segment = False
        text_segment = False
        is_sub_segment = 0
        question_id = 0

        message = request.POST.get('input')
        segment_message = request.POST.get('segment_input')
        segment_qu_id = request.POST.get('segment_qu_id')
        request.session['original_text'] = message

        if (segment_message != ''):
            segment_message = segment_message.strip()
            segment_qu_id = segment_qu_id.strip()
            segment_ans_list = segment_message.split('/')
            segment_qu_id_list = segment_qu_id.split(',')
            ans_index = 0
            for qu_id in segment_qu_id_list:

                index = 0
                for qu in request.session['question_asked']:
                    if (int(qu) == int(qu_id)):
                        if (request.session['answer_received'][index].strip() == '?'):
                            request.session['answer_received'][index] = segment_ans_list[ans_index]
                    if (index < len(request.session['answer_received']) - 1):
                        index = index + 1
                ans_index = ans_index + 1

        # get all intents name
        intents_object = Intent.objects.all()
        intents_name = []
        for intent in intents_object:
            if (Question.objects.filter(intent_id=intent.intent_id).count() > 0):
                intents_name.append(intent.intent_name.replace(
                    '_', ' ').capitalize().strip())

        # Check whether the user has answered the basic information questions
        if not request.session['user_info_complete']:
            # Create a dictionary to map chat_info fields to question_ids
            user_info_dict = {7: 'sex'}

            if 'info_questions' not in request.session:
                request.session['info_questions'] = list(
                    Question.objects.filter(intent_id_id=1).filter(question_order__gte=0).order_by('question_order',
                                                                                                   'question_sub_order').
                        values_list('question_id', flat=True))

                question = Question.objects.get(
                    question_id=request.session['info_questions'][0])
                chat_response = question.question_text.capitalize()
                text_length = question.answer_length
                chat_response = get_chat_response(
                    chat_response, request.session['group_question_list'], question.question_id)
                try:
                    request.session['group_item_no'].append(chat_response[
                                                            chat_response.index("#") + 1: chat_response.index(":")])
                except:
                    print(str(1))

                is_sub_segment = get_is_sub_segment(question)
                if (is_sub_segment > 0):
                    question_id = question.question_id

                if question.question_type == 2:
                    ask_int = True
                elif question.question_type == 3:
                    pop_ups = {'option1': 'yes', 'option2': 'no'}
                elif question.question_type == 4:
                    pop_ups = create_popups(question.choices.split(','))
                elif question.question_type == 5:
                    multiselect = create_popups(question.choices.split(','))
                elif question.question_type == 6:
                    check_boxes = create_popups(question.choices.split(','))
                elif question.question_type == 7:
                    dropdown = [x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                                for x in question.choices.split(',')]
                elif question.question_type == 8:
                    ask_date = True
                elif question.question_type == 9:
                    ask_date_only = True
                elif question.question_type == 10:
                    ask_time_only = True
                elif question.question_type == 11:
                    singleselect_positive = create_popups(question.choices.split(','))
                elif question.question_type == 12:
                    singleselect_negative = create_popups(question.choices.split(','))
                elif question.question_type == 13:
                    multiselect_positive = create_popups(question.choices.split(','))
                elif question.question_type == 14:
                    multiselect_negative = create_popups(question.choices.split(','))
                elif question.question_type == 15:
                    singleselect_positive_negative = create_popups(question.choices.split(','))
                elif question.question_type == 16:
                    multiselect_positive_negative = create_popups(question.choices.split(','))
                elif question.question_type == 17:
                    singleselect_positive_negative = create_popups(question.choices.split(','))
                elif question.question_type == 18:
                    multiselect_positive_negative = create_popups(question.choices.split(','))
                elif question.question_type == 20:
                    text_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 21:
                    integer_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 22:
                    integer_range_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 23:
                    integer_range = question.choices.strip()
                elif question.question_type == 24:
                    segment = True
                elif question.question_type == 25:
                    text_segment = True

                request.session['question_asked'].append(question.question_id)
                request.session['info_questions'].pop(0)

            elif len(request.session['info_questions']) > 0:
                question = Question.objects.get(
                    question_id=request.session['info_questions'][0])
                chat_response = question.question_text.capitalize()
                text_length = question.answer_length
                chat_response = get_chat_response(
                    chat_response, request.session['group_question_list'], question.question_id)
                try:
                    request.session['group_item_no'].append(chat_response[
                                                            chat_response.index("#") + 1: chat_response.index(":")])
                except:
                    request.session['group_item_no'].append(str(0))

                is_sub_segment = get_is_sub_segment(question)
                if (is_sub_segment > 0):
                    question_id = question.question_id
                if question.question_type == 2:
                    ask_int = True
                elif question.question_type == 3:
                    pop_ups = {'option1': 'yes', 'option2': 'no'}
                elif question.question_type == 4:
                    pop_ups = create_popups(question.choices.split(','))
                elif question.question_type == 5:
                    multiselect = create_popups(question.choices.split(','))
                elif question.question_type == 6:
                    check_boxes = create_popups(question.choices.split(','))
                elif question.question_type == 7:
                    dropdown = [x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                                for x in question.choices.split(',')]
                elif question.question_type == 8:
                    ask_date = True
                elif question.question_type == 9:
                    ask_date_only = True
                elif question.question_type == 10:
                    ask_time_only = True
                elif question.question_type == 11:
                    singleselect_positive = create_popups(
                        question.choices.split(','))
                elif question.question_type == 12:
                    singleselect_negative = create_popups(
                        question.choices.split(','))

                elif question.question_type == 13:
                    multiselect_positive = create_popups(
                        question.choices.split(','))
                elif question.question_type == 14:
                    multiselect_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 15:
                    singleselect_positive_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 16:
                    multiselect_positive_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 17:
                    singleselect_positive_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 18:
                    multiselect_positive_negative = create_popups(
                        question.choices.split(','))

                elif question.question_type == 20:
                    text_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 21:
                    integer_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 22:
                    integer_range_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 23:
                    integer_range = question.choices.strip()
                elif question.question_type == 24:
                    segment = True
                elif question.question_type == 25:
                    text_segment = True

                request.session['question_asked'].append(question.question_id)
                request.session['info_questions'].pop(0)

            else:

                request.session['answer_received'].append(message)

                request.session['user_info_complete'] = True

                # Save the responses to the database
                chat_info = {}

                # Check whether the user has visited in the past two years
                previous_visits = ChatInfo.objects.filter(name=request.session['name'],
                                                          email_address=request.session['email_id'],
                                                          phone_number=request.session('phone_number'),
                                                          date_of_birth=datetime.strptime(
                                                              request.session['date_of_birth'], '%Y-%m-%d'),
                                                          chat_ended__gte=timezone.now().date() - timedelta(days=730))

                request.session['first_visit'] = not len(previous_visits) > 0

                # If it's not the patient's first visit, check if they've completed the registration forms
                if not request.session['first_visit']:
                    latest_visit = previous_visits.latest('chat_ended')
                    request.session['registration_form'] = latest_visit.registration_form
                    request.session['clinical_form'] = latest_visit.clinical_form

                for question, answer in zip(request.session['question_asked'], request.session['answer_received']):
                    # Map Yes/No boolean answer to True/False respectively
                    if Question.objects.get(question_id=question).question_type == 3:
                        answer = bool(answer)

                    chat_info[user_info_dict[question]] = answer

                x = ChatInfo(name=request.session['name'],
                             email_address=request.session['email_id'],
                             phone_number=request.session['phone_number'],
                             date_of_birth=datetime.strptime(
                                 request.session['date_of_birth'], '%Y-%m-%d'),
                             sex=get_sex(chat_info['sex']),
                             first_visit=request.session['first_visit'],
                             registration_form=request.session['registration_form'],
                             clinical_form=request.session['clinical_form'],
                             chat_ended=timezone.now())
                x.full_clean()
                x.save()
                request.session['chat_id'] = x.chat_id

                del request.session['info_questions']

                request.session['question_asked'] = []
                request.session['answer_received'] = []

                chat_response = 'Thank you! Those are all of my questions. How may I help you today?'
                text_length = 256
                request.session['accept_intent'] = True

            response['message'] = {'text': chat_response, 'user': False, 'chat_bot': True, 'pop_ups': pop_ups,
                                   'ask_date': ask_date, 'ask_int': ask_int, 'ask_time_only': ask_time_only,
                                   'ask_date_only': ask_date_only, 'check_boxes': check_boxes,
                                   'multiselect': multiselect,
                                   'dropdown': dropdown, 'multiselect_positive': multiselect_positive,
                                   'multiselect_negative': multiselect_negative,
                                   'singleselect_positive': singleselect_positive,
                                   'singleselect_negative': singleselect_negative,
                                   'singleselect_positive_negative': singleselect_positive_negative,
                                   'multiselect_positive_negative': multiselect_positive_negative,
                                   'singleselect_positive_negative_noa': singleselect_positive_negative_noa,
                                   'multiselect_positive_negative_noa': multiselect_positive_negative_noa,
                                   'integer_range_and_dropdown': integer_range_and_dropdown,
                                   'text_and_dropdown': text_and_dropdown, 'integer_and_dropdown': integer_and_dropdown,
                                   'integer_range': integer_range, 'segment': segment, 'is_sub_segment': is_sub_segment,
                                   'text_segment': text_segment,
                                   'question_id': question_id, 'text_length': text_length, 'intents_name': intents_name}
            if (is_sub_segment == 0):
                time.sleep(2)
            else:
                time.sleep(0)

            return HttpResponse(
                json.dumps(response),
                content_type="application/json"
            )

        # Check whether the user has any more inquiries
        if request.session['continue_asked']:
            if message.lower() == 'yes':
                request.session['continue_asked'] = False
                chat_response = 'What else can I help you with today?'
                request.session['question_asked'] = []
                request.session['answer_received'] = []
                request.session['accept_intent'] = True
            else:
                if message.lower() == 'done':
                    if request.session['form_type'] == 'registration':
                        request.session['registration_form'] = True
                        ChatInfo.objects.filter(pk=request.session['chat_id']).update(registration_form=request.
                                                                                      session['registration_form'])

                    elif request.session['form_type'] == 'clinical':
                        request.session['clinical_form'] = True
                        ChatInfo.objects.filter(pk=request.session['chat_id']).update(clinical_form=request.
                                                                                      session['clinical_form'])

                elif message.lower() == 'front desk' or request.session['form_type'] == 'front_desk':
                    # Check if the message is front desk, this means that the user hasn't been asked any front desk
                    # questions yet - need to retrieve them
                    if message.lower() == 'front desk':
                        # If the user has asked for the front desk because they are unable to complete the form
                        # Set the form to True so it doesn't reach else code block, however, save in database as False
                        if request.session['form_type'] == 'registration':
                            request.session['registration_form'] = True
                            ChatInfo.objects.filter(pk=request.session['chat_id']).update(
                                registration_form=False)
                        elif request.session['form_type'] == 'clinical':
                            request.session['clinical_form'] = True
                            ChatInfo.objects.filter(
                                pk=request.session['chat_id']).update(clinical_form=False)

                        request.session['form_type'] = 'front_desk'

                        # Set the intent to front desk to ask the appropriate questions
                        request.session['intent_name'] = 'front_desk'
                        request.session['intent_id'] = Intent.objects.get(
                            intent_name=request.session['intent_name']).pk

                        # Retrieve the front desk questions
                        request.session['question_list'] = list(Question.objects.filter(
                            intent_id_id=request.session['intent_id']).filter(question_order__gte=0).order_by(
                            'question_order', 'question_sub_order').values_list('question_id', flat=True))

                        # Check Repeat's question validation time
                        temp_list = request.session['question_list']

                        for qu_id in request.session['question_list']:
                            qu = Question.objects.get(question_id=qu_id)
                            repeatFlag = checkRepeatValidTime(
                                qu, request.session['email_id'], request.session['name'],
                                request.session['date_of_birth'])
                            if (repeatFlag):
                                temp_list = temp_list.exclude(
                                    question_id=qu.question_id)

                        request.session['question_list'] = temp_list

                        question = Question.objects.get(
                            question_id=request.session['question_list'][0])
                        chat_response = question.question_text.capitalize()

                        chat_response = get_chat_response(
                            chat_response, request.session['group_question_list'], question.question_id)

                        try:
                            request.session['group_item_no'].append(chat_response[
                                                                    chat_response.index("#") + 1: chat_response.index(
                                                                        ":")])
                        except:
                            request.session['group_item_no'].append(str(0))

                        request.session['question_asked'].append(
                            question.question_id)
                        request.session['question_list'].pop(0)

                    # If form type is front_desk, the front desk questions have been retrieved so we can ask the rest
                    elif (request.session['form_type'] == 'front_desk') and len(request.session['question_list']) != 0:
                        request.session['answer_received'].append(message)

                        question = Question.objects.get(
                            question_id=request.session['question_list'][0])
                        chat_response = question.question_text.capitalize()
                        chat_response = get_chat_response(
                            chat_response, request.session['group_question_list'], question.question_id)
                        try:
                            request.session['group_item_no'].append(chat_response[
                                                                    chat_response.index("#") + 1: chat_response.index(
                                                                        ":")])
                        except:
                            request.session['group_item_no'].append(str(0))

                        request.session['question_asked'].append(
                            question.question_id)
                        request.session['question_list'].pop(0)

                    # When the front desk questions are done, reset the form type to continue the chatbot flow and save
                    # front desk answers
                    elif len(request.session['question_list']) == 0:
                        request.session['answer_received'].append(message)

                        # Save all answers
                        for question, answer, group_item in zip(request.session['question_asked'],
                                                                request.session['answer_received'],
                                                                request.session['group_item_no']):
                            x = Response(chat_id_id=request.session['chat_id'],
                                         question_id_id=question,
                                         answer=answer, group_item_number=group_item)

                            x.full_clean()
                            x.save()

                        # Reset session variables

                        request.session['form_type'] = ''
                        request.session['question_asked'] = []
                        request.session['answer_received'] = []
                        # del request.session['question_list']

                        # Check whether any other forms need to be filled out
                        if not (request.session['registration_form'] and request.session['clinical_form']):
                            if not request.session['registration_form']:
                                # Get the patient registration form URL
                                request.session['form_type'] = 'registration'

                            elif not request.session['clinical_form']:
                                # Get the client registration form URL based on age
                                request.session['form_type'] = 'clinical'

                            chat_response = "Patient Form is excluded"

                            pop_ups = {'option1': 'Done',
                                       'option2': 'Front Desk'}

                        else:
                            chat_response = 'I am glad I was able to help you today. Have a nice day!'
                            # Update chat ended time
                            ChatInfo.objects.filter(pk=request.session['chat_id']).update(
                                chat_ended=timezone.now())

                    else:
                        chat_response = 'I am glad I was able to help you today. Have a nice day!'
                        # Update chat ended time
                        ChatInfo.objects.filter(pk=request.session['chat_id']).update(
                            chat_ended=timezone.now())
                    text_length = 256
                    response['message'] = {'text': chat_response, 'user': False, 'chat_bot': True,
                                           'pop_ups': pop_ups,
                                           'ask_date': ask_date,
                                           'ask_int': ask_int, 'ask_time_only': ask_time_only,
                                           'ask_date_only': ask_date_only,
                                           'check_boxes': check_boxes,
                                           'multiselect': multiselect,
                                           'dropdown': dropdown,
                                           'multiselect_positive': multiselect_positive,
                                           'multiselect_negative': multiselect_negative,
                                           'singleselect_positive': singleselect_positive,
                                           'singleselect_negative': singleselect_negative,
                                           'singleselect_positive_negative': singleselect_positive_negative,
                                           'multiselect_positive_negative': multiselect_positive_negative,
                                           'singleselect_positive_negative_noa': singleselect_positive_negative_noa,
                                           'multiselect_positive_negative_noa': multiselect_positive_negative_noa,
                                           'integer_range_and_dropdown': integer_range_and_dropdown,
                                           'text_and_dropdown': text_and_dropdown,
                                           'integer_and_dropdown': integer_and_dropdown,
                                           'integer_range': integer_range, 'segment': segment,
                                           'is_sub_segment': is_sub_segment, 'text_segment': text_segment,
                                           'question_id': question_id, 'text_length': text_length,
                                           'intents_name': intents_name}
                    response['status'] = 'ok'
                    if (is_sub_segment == 0):
                        time.sleep(2)
                    else:
                        time.sleep(0)

                    return HttpResponse(
                        json.dumps(response),
                        content_type="application/json"
                    )

                # Check whether the patient forms have been filled out
                if not (request.session['registration_form'] and request.session['clinical_form']):
                    if not request.session['registration_form']:
                        # Get the patient registration form URL
                        request.session['form_type'] = 'registration'

                    elif not request.session['clinical_form']:
                        # Get the client registration form URL based on age
                        request.session['form_type'] = 'clinical'

                    chat_response = "Patient Form is excluded"  # done by Mervat on Dec 2021

                    pop_ups = {'option1': 'Done', 'option2': 'Front Desk'}

                else:
                    chat_response = 'I am glad I was able to help you today. Have a nice day!'
                    # Update chat ended time
                    ChatInfo.objects.filter(pk=request.session['chat_id']).update(
                        chat_ended=timezone.now())
            text_length = 256

            response['message'] = {'text': chat_response, 'user': False, 'chat_bot': True, 'pop_ups': pop_ups,
                                   'ask_date': ask_date, 'ask_int': ask_int, 'ask_time_only': ask_time_only,
                                   'ask_date_only': ask_date_only, 'check_boxes': check_boxes,
                                   'multiselect': multiselect,
                                   'dropdown': dropdown, 'multiselect_positive': multiselect_positive,
                                   'multiselect_negative': multiselect_negative,
                                   'singleselect_positive': singleselect_positive,
                                   'singleselect_negative': singleselect_negative,
                                   'singleselect_positive_negative': singleselect_positive_negative,
                                   'multiselect_positive_negative': multiselect_positive_negative,
                                   'singleselect_positive_negative_noa': singleselect_positive_negative_noa,
                                   'multiselect_positive_negative_noa': multiselect_positive_negative_noa,
                                   'integer_range_and_dropdown': integer_range_and_dropdown,
                                   'text_and_dropdown': text_and_dropdown,
                                   'integer_and_dropdown': integer_and_dropdown,
                                   'integer_range': integer_range, 'segment': segment, 'is_sub_segment': is_sub_segment,
                                   'text_segment': text_segment,
                                   'question_id': question_id, 'text_length': text_length, 'intents_name': intents_name}
            response['status'] = 'ok'
            if (is_sub_segment == 0):
                time.sleep(2)
            else:
                time.sleep(0)

            return HttpResponse(
                json.dumps(response),
                content_type="application/json"
            )

        # Check whether the the user has any associated symptoms
        if request.session['ask_associated_symptoms']:
            text_length = 265
            if message.lower() == 'yes':
                request.session['ask_associated_symptoms'] = False
                chat_response = 'Please describe any associated symptoms'

            else:

                chat_response = 'Is there anything else I can help you with today?'
                pop_ups = {'option1': 'yes', 'option2': 'no'}
                request.session['is_appointment'] = False
                request.session['ask_associated_symptoms'] = False
                request.session['continue_asked'] = True
                request.session['accept_intent'] = False

            response['message'] = {'text': chat_response, 'user': False, 'chat_bot': True, 'pop_ups': pop_ups,
                                   'ask_date': ask_date, 'ask_int': ask_int, 'ask_time_only': ask_time_only,
                                   'ask_date_only': ask_date_only, 'check_boxes': check_boxes,
                                   'multiselect': multiselect,
                                   'dropdown': dropdown, 'multiselect_positive': multiselect_positive,
                                   'multiselect_negative': multiselect_negative,
                                   'singleselect_positive': singleselect_positive,
                                   'singleselect_negative': singleselect_negative,
                                   'singleselect_positive_negative': singleselect_positive_negative,
                                   'multiselect_positive_negative': multiselect_positive_negative,
                                   'singleselect_positive_negative_noa': singleselect_positive_negative_noa,
                                   'multiselect_positive_negative_noa': multiselect_positive_negative_noa,
                                   'integer_range_and_dropdown': integer_range_and_dropdown,
                                   'text_and_dropdown': text_and_dropdown,
                                   'integer_and_dropdown': integer_and_dropdown,
                                   'integer_range': integer_range, 'segment': segment, 'is_sub_segment': is_sub_segment,
                                   'text_segment': text_segment,
                                   'question_id': question_id, 'text_length': text_length
                                   }
            response['status'] = 'ok'

            if (is_sub_segment == 0):
                time.sleep(2)
            else:
                time.sleep(0)

            return HttpResponse(
                json.dumps(response),
                content_type="application/json"
            )

        # Check whether there are questions lined up, if not, classify intent and extract questions related to intent
        if 'question_list' not in request.session or request.session['accept_intent']:

            if message.lower() in inquiry_dict:
                request.session['intent_name'] = inquiry_dict[message.lower()]
                request.session['intent_id'] = Intent.objects.get(
                    intent_name=request.session['intent_name']).pk
                request.session['probability'] = 1

            else:
                request.session['accept_intent'] = False
                request.session['intent_name'] = message.lower().replace(
                    ' ', '_').strip()

                request.session['intent_id'] = Intent.objects.get(
                    intent_name=request.session['intent_name']).pk

                request.session['probability'] = 1

            # If the bot doesn't understand, it will ask the user to reword their answer
            if float(request.session['probability']) < 0.7:
                if request.session['miscommunication_counter'] == 0:
                    chat_response = "I'm sorry, I didn't quite understand you, can you please explain your symptoms"
                    request.session['miscommunication_counter'] += 1

                elif request.session['miscommunication_counter'] == 1:
                    chat_response = "I'm sorry, I still can't understand you, can you please explain your symptoms again"
                    request.session['miscommunication_counter'] += 1

                # If the bot still can't understand, will direct them to the front desk
                else:
                    # Set the intent to front desk to ask the appropriate questions
                    request.session['intent_name'] = 'front_desk'
                    request.session['intent_id'] = Intent.objects.get(
                        intent_name=request.session['intent_name']).pk

                    # Retrieve the front desk questions
                    request.session['question_list'] = list(Question.objects.filter(
                        intent_id_id=request.session['intent_id']).filter(question_order__gte=0).order_by(
                        'question_order', 'question_sub_order').values_list('question_id', flat=True))
                    # Check Repeat's question validation time
                    temp_list = request.session['question_list']

                    for qu in request.session['question_list']:
                        repeatFlag = checkRepeatValidTime(
                            qu, request.session['email_id'], request.session['phone_number'], request.session['name'], request.session['date_of_birth'])
                        if (repeatFlag):
                            temp_list = temp_list.exclude(
                                question_id=qu.question_id)

                    request.session['question_list'] = temp_list

                    question = Question.objects.get(
                        question_id=request.session['question_list'][0])
                    chat_response = "I'm sorry I still don't understand, I will direct you to leave a message for the front desk. "

                    chat_response += question.question_text.capitalize()
                    text_length = question.answer_length

                    request.session['question_asked'].append(
                        question.question_id)
                    request.session['question_list'].pop(0)

                    # Reset miscommunication counter back to 0
                    request.session['miscommunication_counter'] = 0

                response['message'] = {'text': chat_response, 'user': False, 'chat_bot': True, 'pop_ups': pop_ups,
                                       'ask_date': ask_date, 'ask_int': ask_int, 'ask_time_only': ask_time_only,
                                       'ask_date_only': ask_date_only, 'check_boxes': check_boxes,
                                       'multiselect': multiselect,
                                       'dropdown': dropdown, 'multiselect_positive': multiselect_positive,
                                       'multiselect_negative': multiselect_negative,
                                       'singleselect_positive': singleselect_positive,
                                       'singleselect_negative': singleselect_negative,
                                       'singleselect_positive_negative': singleselect_positive_negative,
                                       'multiselect_positive_negative': multiselect_positive_negative,
                                       'singleselect_positive_negative_noa': singleselect_positive_negative_noa,
                                       'multiselect_positive_negative_noa': multiselect_positive_negative_noa,
                                       'integer_range_and_dropdown': integer_range_and_dropdown,
                                       'text_and_dropdown': text_and_dropdown,
                                       'integer_and_dropdown': integer_and_dropdown,
                                       'integer_range': integer_range, 'segment': segment,
                                       'is_sub_segment': is_sub_segment, 'text_segment': text_segment,
                                       'question_id': question_id, 'text_length': text_length}

                response['status'] = 'ok'
                if (is_sub_segment == 0):
                    time.sleep(2)
                else:
                    time.sleep(0)

                return HttpResponse(
                    json.dumps(response),
                    content_type="application/json"
                )

            # If probability of prediction is greater than 0.7, bot proceeds as normal
            else:
                # Reset miscommunication counter back to 0
                request.session['miscommunication_counter'] = 0

                # Only pull questions that apply to the specific age or sex restriction if applicable
                request.session['question_list'] = Question.objects.filter(
                    intent_id_id=request.session['intent_id']).filter(question_order__gte=0).order_by('question_order',
                                                                                                      'question_sub_order')
                # Check Repeat's question validation time
                temp_list = request.session['question_list']

                for qu in request.session['question_list']:
                    repeatFlag = checkRepeatValidTime(
                        qu, request.session['email_id'], request.session['phone_numnber'], request.session['name'], request.session['date_of_birth'])
                    if (repeatFlag):
                        temp_list = temp_list.exclude(
                            question_id=qu.question_id)

                request.session['question_list'] = temp_list
                #
                filtered_questions = []
                for question in request.session['question_list']:
                    age_check = True
                    sex_check = True
                    if question.age_restriction:
                        age_check = question.age_range_lower <= request.session[
                            'age'] < question.age_range_upper

                    if question.sex_restriction:
                        sex_check = question.sex == ChatInfo.objects.get(
                            pk=request.session['chat_id']).sex

                    append = age_check and sex_check

                    if append:
                        filtered_questions.append(question.question_id)

                # Update the question list
                request.session['question_list'] = filtered_questions

                if request.session['intent_name'] == 'appointment':
                    request.session['is_appointment'] = True

            # If no questions exist, add the intent to the 'other' intent as an answer
            if len(request.session['question_list']) != 0:

                question = Question.objects.get(
                    question_id=request.session['question_list'][0])
                is_sub_segment = get_is_sub_segment(question)
                if (is_sub_segment > 0):
                    question_id = question.question_id

                if question.question_type == 2:
                    ask_int = True
                elif question.question_type == 3:
                    pop_ups = {'option1': 'yes', 'option2': 'no'}
                elif question.question_type == 4:
                    pop_ups = create_popups(question.choices.split(','))
                elif question.question_type == 5:
                    multiselect = create_popups(question.choices.split(','))
                elif question.question_type == 6:
                    check_boxes = create_popups(question.choices.split(','))
                elif question.question_type == 7:
                    dropdown = [x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                                for x in question.choices.split(',')]
                elif question.question_type == 8:
                    ask_date = True
                elif question.question_type == 9:
                    ask_date_only = True
                elif question.question_type == 10:
                    ask_time_only = True
                elif question.question_type == 11:
                    singleselect_positive = create_popups(
                        question.choices.split(','))
                elif question.question_type == 12:
                    singleselect_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 13:
                    multiselect_positive = create_popups(
                        question.choices.split(','))
                elif question.question_type == 14:
                    multiselect_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 15:
                    singleselect_positive_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 16:
                    multiselect_positive_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 17:
                    singleselect_positive_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 18:
                    multiselect_positive_negative = create_popups(
                        question.choices.split(','))

                elif question.question_type == 20:
                    text_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 21:
                    integer_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 22:
                    integer_range_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 23:
                    integer_range = question.choices.strip()
                elif question.question_type == 24:
                    segment = True
                elif question.question_type == 25:
                    text_segment = True

                chat_response = question.question_text.capitalize()

                chat_response = get_chat_response(
                    chat_response, request.session['group_question_list'], question.question_id)
                try:
                    request.session['group_item_no'].append(chat_response[
                                                            chat_response.index("#") + 1: chat_response.index(":")])
                except:
                    request.session['group_item_no'].append(str(0))

                # Set flag accordingly if follow up is required
                request.session['follow_up_check'] = question.follow_up
                if question.group_id is not None:
                    request.session['group_id'] = (question.group_id).group_id
                else:
                    request.session['group_id'] = None

                request.session['question_asked'].append(question.question_id)
                request.session['question_list'].pop(0)
            else:
                request.session['no_question_intent'].append(
                    request.session['intent_name'])

                # If this is an appointment inquiry, ask if there are associated symptoms
                # Otherwise, ask if there is anything else they need help with
                if request.session['is_appointment'] and not request.session['intent_name'] == 'front_desk':
                    request.session['ask_associated_symptoms'] = True
                    chat_response = 'Are there any other associated symptoms?'
                    pop_ups = {'option1': 'yes', 'option2': 'no'}
                else:
                    chat_response = 'Is there anything else I can help you with today?'
                    request.session['continue_asked'] = True
                    request.session['is_appointment'] = False
                    pop_ups = {'option1': 'yes', 'option2': 'no'}

        # If there are still questions for the intent, they will be asked here
        elif len(request.session['question_list']) > 0 or request.session['follow_up_check'] or request.session[
            'group_id'] is not None:

            # Save the follow up answer if it exists, otherwise, add a blank entry
            if request.session['follow_up_asked']:
                request.session['follow_up_asked'] = False
            else:
                request.session['answer_received'].append(message)

            # Check whether the follow up question needs to be asked before the next question on the list
            if request.session['follow_up_check']:
                prev_question = Question.objects.get(
                    question_id=request.session['question_asked'][-1])
                answer_list = message.split(',')
                qu_id_list = []
                for ans in answer_list:
                    follow_up_qu = FollowUpQuestion.objects.filter(
                        question_id=prev_question).filter(option=ans.lower().strip()).order_by('-follow_up_id')

                    if (len(follow_up_qu) > 0):
                        for fol_qu_id in follow_up_qu:
                            qu_id_list.append(
                                fol_qu_id.follow_up_question_id.question_id)
                        for qu_id in qu_id_list:
                            request.session['question_list'].insert(
                                0, qu_id)
                if (len(request.session['question_list']) == 0):
                    # added to change the flow and allows user to enter intent
                    chat_response = 'Is there anything else I can help you with today?'
                    request.session['continue_asked'] = True
                    pop_ups = {'option1': 'yes', 'option2': 'no'}

                    ####
                else:
                    question = Question.objects.get(
                        question_id=request.session['question_list'][0])
                    is_sub_segment = get_is_sub_segment(question)
                    if (is_sub_segment > 0):
                        question_id = question.question_id

                    if question.question_type == 2:
                        ask_int = True
                    elif question.question_type == 3:
                        pop_ups = {'option1': 'yes', 'option2': 'no'}
                    elif question.question_type == 4:
                        pop_ups = create_popups(
                            question.choices.split(','))
                    elif question.question_type == 5:
                        multiselect = create_popups(
                            question.choices.split(','))
                    elif question.question_type == 6:
                        check_boxes = create_popups(
                            question.choices.split(','))
                    elif question.question_type == 7:
                        dropdown = [x.replace('_', ' ').strip() if x.isupper()
                                    else x.replace('_', ' ').strip().capitalize() for x in question.choices.split(',')]
                    elif question.question_type == 8:
                        ask_date = True
                    elif question.question_type == 9:
                        ask_date_only = True
                    elif question.question_type == 10:
                        ask_time_only = True
                    elif question.question_type == 11:
                        singleselect_positive = create_popups(
                            question.choices.split(','))
                    elif question.question_type == 12:
                        singleselect_negative = create_popups(
                            question.choices.split(','))
                    elif question.question_type == 13:
                        multiselect_positive = create_popups(
                            question.choices.split(','))
                    elif question.question_type == 14:
                        multiselect_negative = create_popups(
                            question.choices.split(','))
                    elif question.question_type == 15:
                        singleselect_positive_negative = create_popups(
                            question.choices.split(','))
                    elif question.question_type == 16:
                        multiselect_positive_negative = create_popups(
                            question.choices.split(','))
                    elif question.question_type == 17:
                        singleselect_positive_negative = create_popups(
                            question.choices.split(','))
                    elif question.question_type == 18:
                        multiselect_positive_negative = create_popups(
                            question.choices.split(','))

                    elif question.question_type == 20:
                        text_and_dropdown = [
                            x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                            for x in question.choices.split(',')]
                    elif question.question_type == 21:
                        integer_and_dropdown = [
                            x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                            for x in question.choices.split(',')]
                    elif question.question_type == 22:
                        integer_range_and_dropdown = [
                            x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                            for x in question.choices.split(',')]
                    elif question.question_type == 23:
                        integer_range = question.choices.strip()
                    elif question.question_type == 24:
                        segment = True
                    elif question.question_type == 25:
                        text_segment = True

                    chat_response = question.question_text.capitalize()

                    chat_response = get_chat_response(
                        chat_response, request.session['group_question_list'], question.question_id)
                    try:
                        request.session['group_item_no'].append(chat_response[
                                                                chat_response.index("#") + 1: chat_response.index(":")])
                    except:
                        request.session['group_item_no'].append(str(0))

                    # Set flag accordingly if follow up is required
                    request.session['follow_up_check'] = question.follow_up
                    if question.group_id is not None:
                        request.session['group_id'] = (
                            question.group_id).group_id
                        request.session['group_for_each'] = (
                            question.group_id).group_for_each
                    else:
                        request.session['group_id'] = None
                        request.session['group_for_each'] = 0

                    request.session['question_asked'].append(
                        question.question_id)
                    request.session['question_list'].pop(0)
                    ####
            elif request.session['group_id'] is not None:
                repetition_times = int(request.session['answer_received'][-1])
                prev_question = Question.objects.get(
                    question_id=request.session['question_asked'][-1])

                group_id = (prev_question.group_id).group_id
                request.session['group_for_each'] = (
                    prev_question.group_id).group_for_each
                if GroupInfo.objects.filter(group_id = group_id).exists():
                    group_question_list = Question.objects.filter(session_id = GroupInfo.objects.filter(group_id = group_id)[0].session_key).order_by('timestamp').reverse()

                # group_question_list = GroupQuestion.objects.filter(
                #     group_id=group_id).order_by('question_order').reverse()

                for i in range(repetition_times):
                    for qu in group_question_list:
                        request.session['question_list'].insert(
                            0, (qu.question_id).question_id)
                        request.session['group_question_list']['qu_id'].append(
                            (qu.question_id).question_id)
                        request.session['group_question_list']['for_each'].append(
                            (qu.group_id).group_for_each)
                        request.session['group_question_list']['no'].append(
                            i)

                question = Question.objects.get(
                    question_id=request.session['question_list'][0])
                is_sub_segment = get_is_sub_segment(question)
                if (is_sub_segment > 0):
                    question_id = question.question_id

                if question.question_type == 2:
                    ask_int = True
                elif question.question_type == 3:
                    pop_ups = {'option1': 'yes', 'option2': 'no'}
                elif question.question_type == 4:
                    pop_ups = create_popups(question.choices.split(','))
                elif question.question_type == 5:
                    multiselect = create_popups(
                        question.choices.split(','))
                elif question.question_type == 6:
                    check_boxes = create_popups(
                        question.choices.split(','))
                elif question.question_type == 7:
                    dropdown = [x.replace('_', ' ').strip() if x.isupper()
                                else x.replace('_', ' ').strip().capitalize() for x in question.choices.split(',')]
                elif question.question_type == 8:
                    ask_date = True
                elif question.question_type == 9:
                    ask_date_only = True
                elif question.question_type == 10:
                    ask_time_only = True
                elif question.question_type == 11:
                    singleselect_positive = create_popups(
                        question.choices.split(','))
                elif question.question_type == 12:
                    singleselect_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 13:
                    multiselect_positive = create_popups(
                        question.choices.split(','))
                elif question.question_type == 14:
                    multiselect_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 15:
                    singleselect_positive_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 16:
                    multiselect_positive_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 17:
                    singleselect_positive_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 18:
                    multiselect_positive_negative = create_popups(
                        question.choices.split(','))

                elif question.question_type == 20:
                    text_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 21:
                    integer_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 22:
                    integer_range_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 23:
                    integer_range = question.choices.strip()
                elif question.question_type == 24:
                    segment = True
                elif question.question_type == 25:
                    text_segment = True

                chat_response = question.question_text.capitalize()

                chat_response = get_chat_response(
                    chat_response, request.session['group_question_list'], question.question_id)
                try:
                    request.session['group_item_no'].append(chat_response[
                                                            chat_response.index("#") + 1: chat_response.index(":")])
                except:
                    request.session['group_item_no'].append(str(0))

                # Set flag accordingly if follow up is required
                request.session['follow_up_check'] = question.follow_up

                if question.group_id is not None:
                    request.session['group_id'] = (question.group_id).group_id
                else:
                    request.session['group_id'] = None

                request.session['question_asked'].append(
                    question.question_id)
                request.session['question_list'].pop(0)

            else:
                question = Question.objects.get(
                    question_id=request.session['question_list'][0])
                is_sub_segment = get_is_sub_segment(question)
                if (is_sub_segment > 0):
                    question_id = question.question_id
                if question.question_type == 2:
                    ask_int = True
                elif question.question_type == 3:
                    pop_ups = {'option1': 'yes', 'option2': 'no'}
                elif question.question_type == 4:
                    pop_ups = create_popups(question.choices.split(','))
                elif question.question_type == 5:
                    multiselect = create_popups(question.choices.split(','))
                elif question.question_type == 6:
                    check_boxes = create_popups(question.choices.split(','))
                elif question.question_type == 7:
                    dropdown = [x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                                for x in question.choices.split(',')]
                elif question.question_type == 8:
                    ask_date = True
                elif question.question_type == 9:
                    ask_date_only = True
                elif question.question_type == 10:
                    ask_time_only = True
                elif question.question_type == 11:
                    singleselect_positive = create_popups(
                        question.choices.split(','))
                elif question.question_type == 12:
                    singleselect_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 13:
                    multiselect_positive = create_popups(
                        question.choices.split(','))
                elif question.question_type == 14:
                    multiselect_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 15:
                    singleselect_positive_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 16:
                    multiselect_positive_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 17:
                    singleselect_positive_negative = create_popups(
                        question.choices.split(','))
                elif question.question_type == 18:
                    multiselect_positive_negative = create_popups(
                        question.choices.split(','))

                elif question.question_type == 20:
                    text_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 21:
                    integer_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 22:
                    integer_range_and_dropdown = [
                        x.replace('_', ' ').strip() if x.isupper() else x.replace('_', ' ').strip().capitalize()
                        for x in question.choices.split(',')]
                elif question.question_type == 23:
                    integer_range = question.choices.strip()
                elif question.question_type == 24:
                    segment = True
                elif question.question_type == 25:
                    text_segment = True

                chat_response = question.question_text.capitalize()

                chat_response = get_chat_response(
                    chat_response, request.session['group_question_list'], question.question_id)
                try:
                    request.session['group_item_no'].append(chat_response[
                                                            chat_response.index("#") + 1: chat_response.index(":")])
                except:
                    request.session['group_item_no'].append(str(0))

                # Set flag accordingly if follow up is required
                request.session['follow_up_check'] = question.follow_up

                if question.group_id is not None:
                    request.session['group_id'] = (question.group_id).group_id
                    request.session['group_for_each'] = (
                        question.group_id).group_for_each
                else:
                    request.session['group_id'] = None
                    request.session['group_for_each'] = 0

                request.session['question_asked'].append(question.question_id)
                request.session['question_list'].pop(0)

        # Once there are no more questions, the chatbot will ask if the user has any more questions
        else:

            # Save the follow up answer if it exists, otherwise, add a blank entry
            if request.session['follow_up_asked']:
                # request.session['description_received'][-1] = message
                request.session['follow_up_asked'] = False
            else:
                request.session['answer_received'].append(message)

            # Check first whether the follow up question needs to be asked before the next question on the list
            if request.session['follow_up_check']:
                question = Question.objects.get(
                    question_id=request.session['question_asked'][-1])
                # Check whether the message received matches the required answer to prompt the follow up question
                if message.lower() in question.follow_up_answer.lower():
                    chat_response = question.follow_up_question_text.capitalize()
                    text_length = question.answer_length
                    request.session['follow_up_asked'] = True

                    # Set flag back to False
                    request.session['follow_up_check'] = False

                    response['message'] = {'text': chat_response, 'user': False, 'chat_bot': True, 'pop_ups': pop_ups,
                                           'ask_date': ask_date, 'ask_int': ask_int, 'ask_time_only': ask_time_only,
                                           'ask_date_only': ask_date_only, 'check_boxes': check_boxes,
                                           'multiselect': multiselect,
                                           'dropdown': dropdown, 'multiselect_positive': multiselect_positive,
                                           'multiselect_negative': multiselect_negative,
                                           'singleselect_positive': singleselect_positive,
                                           'singleselect_negative': singleselect_negative,
                                           'singleselect_positive_negative': singleselect_positive_negative,
                                           'multiselect_positive_negative': multiselect_positive_negative,
                                           'singleselect_positive_negative_noa': singleselect_positive_negative_noa,
                                           'multiselect_positive_negative_noa': multiselect_positive_negative_noa,
                                           'integer_range_and_dropdown': integer_range_and_dropdown,
                                           'text_and_dropdown': text_and_dropdown,
                                           'integer_and_dropdown': integer_and_dropdown,
                                           'integer_range': integer_range, 'segment': segment,
                                           'is_sub_segment': is_sub_segment, 'text_segment': text_segment,
                                           'question_id': question_id, 'text_length': text_length}

                    response['status'] = 'ok'

                    if (is_sub_segment == 0):
                        time.sleep(2)
                    else:
                        time.sleep(0)

                    return HttpResponse(
                        json.dumps(response),
                        content_type="application/json"
                    )

            # Save the responses to the database

            for question, answer, group_item in zip(request.session['question_asked'],
                                                    request.session['answer_received'],
                                                    request.session['group_item_no']):
                x = Response(chat_id_id=request.session['chat_id'],
                             question_id_id=question,
                             answer=answer,
                             group_item_number=group_item)

                x.full_clean()
                x.save()

            request.session['question_asked'] = []
            request.session['answer_received'] = []

            # If in the appointment intent, the chatbot will ask if there are associated symptoms
            if request.session['is_appointment']:
                if request.session['intent_name'] == 'appointment':
                    chat_response = 'Please describe the reason you wish to book an appointment'

                else:
                    request.session['ask_associated_symptoms'] = True
                    chat_response = 'Are there any other associated symptoms?'
                    pop_ups = {'option1': 'yes', 'option2': 'no'}

            else:

                chat_response = 'Is there anything else I can help you with today?'
                request.session['continue_asked'] = True
                request.session['is_appointment'] = False
                pop_ups = {'option1': 'yes', 'option2': 'no'}

        if (chat_response is None):
            print("4:help you with today?")
            chat_response = 'Is there anything else I can help you with today?'
            request.session['continue_asked'] = True
            request.session['is_appointment'] = False
            pop_ups = {'option1': 'yes', 'option2': 'no'}

        text_length = 256
        response['message'] = {'text': chat_response, 'user': False, 'chat_bot': True, 'pop_ups': pop_ups,
                               'ask_date': ask_date, 'ask_int': ask_int, 'ask_time_only': ask_time_only,
                               'ask_date_only': ask_date_only, 'check_boxes': check_boxes, 'multiselect': multiselect,
                               'dropdown': dropdown, 'multiselect_positive': multiselect_positive,
                               'multiselect_negative': multiselect_negative,
                               'singleselect_positive': singleselect_positive,
                               'singleselect_negative': singleselect_negative,
                               'singleselect_positive_negative': singleselect_positive_negative,
                               'multiselect_positive_negative': multiselect_positive_negative,
                               'singleselect_positive_negative_noa': singleselect_positive_negative_noa,
                               'multiselect_positive_negative_noa': multiselect_positive_negative_noa,
                               'integer_range_and_dropdown': integer_range_and_dropdown,
                               'text_and_dropdown': text_and_dropdown,
                               'integer_and_dropdown': integer_and_dropdown,
                               'integer_range': integer_range, 'segment': segment, 'is_sub_segment': is_sub_segment,
                               'text_segment': text_segment, 'question_id': question_id, 'text_length': text_length}

        response['status'] = 'ok'

        for key, value in request.session.items():
            print('{} => {}'.format(key, value))

    else:
        response['error'] = 'no post data found'

    if (is_sub_segment == 0):
        time.sleep(2)
    else:
        time.sleep(0)

    return HttpResponse(
        json.dumps(response),
        content_type="application/json"
    )


def create_popups(lst):
    i = 0
    pop_ups = {}
    lst = [x.replace('_', ' ').strip() for x in lst]
    for item in lst:
        pop_ups[f'option{i}'] = item
        i += 1
    return pop_ups


def calculate_age(born):
    today = timezone.now().date()
    difference = relativedelta.relativedelta(today, born)
    age = difference.years * 14 + difference.months
    return age


def get_is_sub_segment(question):
    question_order = int(question.question_order)
    question_segment_count = int(Question.objects.filter(
        question_order=question_order).count())
    question_sub_order = int(question.question_sub_order)
    # check if the question has sub_order ( it belongs to a segment)
    if (question_sub_order > 0):
        if (question_sub_order < question_segment_count - 1):
            # it is not question in the segment , that it belongs to
            return 1
        else:
            # last question in the segment, that it belongs to
            return 2
    else:
        # it does not belong to any segment
        return 0


def get_chat_response(chat_response, group_list, question_id):
    indx = 0
    for qu in group_list['qu_id']:
        if (qu == question_id):
            for_each = group_list['for_each'][indx]
            no = group_list['no'][indx]
            group_list['qu_id'][indx] = 0
            return for_each.capitalize() + "# " + str(no + 1) + ": " + chat_response

        indx += 1
    return chat_response


def checkRepeatValidTime(qu, email_id, phone_number, name, date_of_birth):
    if (qu.repeat_restriction == False):
        return False

    chat_list = ChatInfo.objects.filter(
        name=name, email_address=email_id, phone_number=phone_number, date_of_birth=date_of_birth).order_by('chat_ended')
    if (len(chat_list) == 0):
        return False
    response_flag = False
    for chat_id in chat_list:
        response_list = Response.objects.filter(
            chat_id=chat_id, question_id=qu.question_id).order_by('-answer_id')
        if (len(response_list) == 0):
            continue
        prev_date = response_list[0].chat_id.chat_ended

        diff_days = ((datetime.today()).date() - prev_date.date()).days
        if (diff_days < qu.repeat_days):

            return True

        else:

            return False
    if (response_flag == False):
        return False


def get_sex(sex):
    if sex == 'Male':
        return 'M'
    elif sex == 'Female':
        return 'F'
    elif sex == 'Other':
        return 'O'
    else:
        return 'U'
