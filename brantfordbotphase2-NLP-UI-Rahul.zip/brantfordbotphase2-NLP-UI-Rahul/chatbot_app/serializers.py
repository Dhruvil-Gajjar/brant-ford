from rest_framework import serializers
from .models import Symptom, User

# To retreive the information about the user

class SymptomSerializer(serializers.HyperlinkedModelSerializer):
	class Meta:
		model = Symptom
		fields = ('id', 'url', 'name')

class UserSerializer(serializers.HyperlinkedModelSerializer):
	class Meta:
		model = User
		fields = ('id', 'url', 'name', 'age', 'email_id', 'phone_number', 'symptoms')
