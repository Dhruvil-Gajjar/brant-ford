from django.contrib.auth.base_user import BaseUserManager
from django.contrib.auth.models import AbstractUser
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator
from django.db import models
from django.utils.translation import gettext_lazy as _
# Create your models here.

class CustomUserManager(BaseUserManager):

    # Custom user model
    # email (primary key) used for authentication instead of usernames

    def create_user(self, email, password, **extra_fields):
        if not email:
            raise ValueError(_('The Email must be set'))
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.username = email
        user.save()
        return user

    def create_superuser(self, email, password, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError(_('Superuser must have is_staff=True.'))
        if extra_fields.get('is_superuser') is not True:
            raise ValueError(_('Superuser must have is_superuser=True.'))
        return self.create_user(email, password, **extra_fields)


class CustomUser(AbstractUser):
    email = models.EmailField(_('email address'), unique=True)
    username = models.TextField(unique=True)
    is_provider = models.BooleanField(null=False, blank=False, default=False)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    objects = CustomUserManager()

    def __str__(self):
        return self.email


class Provider(models.Model):
    class Province(models.TextChoices):
        ALBERTA = 'AB'
        BRITISH_COLUMBIA = 'BC'
        MANITOBA = 'MB'
        NEW_BRUNSWICK = 'NB'
        NEWFOUNDLAND_AND_LABRADOR = 'NL'
        NOVA_SCOTIA = 'NS'
        ONTARIO = 'ON'
        PRINCE_EDWARD_ISLAND = 'PE'
        QUEBEC = 'QC'
        SASKATCHEWAN = 'SK'
        NORTHWEST_TERRITORIES = 'NT'
        YUKON = 'YK'
        NUNAVUT = 'NU'

    class ClinicalRole(models.TextChoices):
        FAMILY_PRACTICE_AND_PRACTICE_IN_GENERAL = '00'
        ANAESTHESIA = '01'
        DERMATOLOGY = '02'
        GENERAL_SURGERY = '03'
        NEUROSURGERY = '04'
        COMMUNITY_MEDICINE = '05'
        ORTHOPAEDIC_SURGERY = '06'
        GERIATRICS = '07'
        PLASTIC_SURGERY = '08'
        CARDIOVASCULAR_AND_THORACIC_SURGERY = '09'
        EMERGENCY_MEDICINE = '12'
        INTERNAL_MEDICINE = '13'
        NEUROLOGY = '18'
        PSYCHIATRY = '19'
        OBSTETRICS_AND_GYNAECOLOGY = '20'
        GENETICS = '22'
        OPHTHALMOLOGY = '23'
        OTOLARYNGOLOGY = '24'
        PAEDIATRICS = '26'
        PATHOLOGY = '28'
        MICROBIOLOGY = '29'
        CLINICAL_BIOCHEMISTRY = '30'
        PHYSICAL_MEDICINE = '31'
        DIAGNOSTIC_RADIOLOGY = '33'
        THERAPEUTIC_RADIOLOGY = '34'
        UROLOGY = '35'
        GASTROENTEROLOGY = '41'
        RESPIRATORY_DISEASES = '47'
        RHEUMATOLOGY = '48'
        CARDIOLOGY = '60'
        HAEMATOLOGY = '61'
        CLINICAL_IMMUNOLOGY = '62'
        NUCLEAR_MEDICINE = '63'
        THORACIC_SURGERY = '64'
        DENTAL_SURGERY = '49'
        ORAL_SURGERY = '50'
        ORTHODONTICS = '51'
        PAEDODONTICS = '52'
        PERIODONTICS = '53'
        ORAL_PATHOLOGY = '54'
        ENDODONTICS = '55'
        ORAL_RADIOLOGY = '70'
        PROSTHODONTICS = '71'
        OPTOMETRY = '56'
        OSTEOPATHY = '57'
        CHIROPODY_PODIATRY = '58', 'Chiropody (Podiatry)'
        CHIROPRACTICS = '59'
        MIDWIFE = '75', 'Midwife (Referral Only)'
        PRIVATE_PHYSIOTHERAPY_FACILITY_HOME = '80', 'Private Physiotherapy Facility (Approved to Provide Home Treatment Only)'
        PRIVATE_PHYSIOTHERAPY_FACILITY_OFFICE_AND_HOME = '81', 'Private Physiotherapy Facility (Approved to Provide Office and Home Treatment)'
        NON_MEDICAL_LABORATORY_DIRECTOR = '27', 'Non-medical Laboratory Director (Provider Number Must Be 599993)'
        NURSE_PRACTITIONER = '76'
        ALTERNATE_HEALTHCARE_PROFESSION = '85'
        IIHF_NON_MEDICAL_PRACTITIONER = '90', 'IHF Non-Medical Practitioner (Provider Number Must Be 991000)'

    # Validators
    phone_regex = RegexValidator(regex=r'^\+?1?\d{10,13}$',
                                 message="Phone number must be entered in the format: '+999999999'. "
                                         "From 10 to 13 digits allowed.")

    id = models.AutoField(primary_key=True)
    provider_id = models.CharField(max_length=30)
    clinical_role = models.CharField(max_length=30, choices=ClinicalRole.choices, blank=False)
    first_name = models.CharField(max_length=20, blank=False)
    middle_name = models.CharField(max_length=20, blank=True)
    last_name = models.CharField(max_length=20, blank=False)
    business_name = models.CharField(max_length=30, blank=False)
    street = models.CharField(max_length=25, blank=False)
    city = models.CharField(max_length=20, blank=False)
    province = models.CharField(max_length=2, choices=Province.choices, default=Province.ONTARIO, blank=False)
    postal_code = models.CharField(max_length=6, blank=False)
    phone = models.CharField(max_length=20, blank=True, validators=[phone_regex])
    fax = models.CharField(max_length=10, blank=True)
    email = models.EmailField(max_length=50, blank=False)
    hst = models.CharField(max_length=50, blank=True)
    facility = models.CharField(max_length=100, blank=True)
    license1 = models.CharField(max_length=10, blank=True)
    is_approved = models.BooleanField(null=False, blank=False, default=False)
    user_login = models.OneToOneField(CustomUser, on_delete=models.CASCADE, limit_choices_to={'is_provider': True},
                                      null=True, blank=True)

    def __str__(self):
        return f'{self.first_name.capitalize()} {self.last_name.capitalize()}'

    def clean(self):
        if self.is_approved and self.user_login is None:
            raise ValidationError('The provider cannot be approved without an associated user form_generation')
