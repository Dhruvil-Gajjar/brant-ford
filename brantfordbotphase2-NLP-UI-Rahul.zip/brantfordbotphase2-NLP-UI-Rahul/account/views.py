from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods

from account.forms import ProviderForm, CustomUserCreationForm
from account.models import Provider, CustomUser


# Create your views here.


@login_required
@require_http_methods(['GET'])
def home(request):
    return render(request, 'account/home.html')

@login_required
@require_http_methods(['GET', 'POST'])
def provider_requests(request):
    if request.method == 'POST':
        post_data = request.POST.copy()
        provider_id = post_data['provider_id']
        provider = Provider.objects.get(pk=provider_id)
        if post_data['action'] == 'approve':
            if CustomUser.objects.filter(email=post_data['email']).exists():
                messages.error(request, f'Account with email address {post_data["email"]} already exists. '
                                        f'Please contact provider to update email address')
            else:
                password = 'pdfNN7d*pYj2aF3*'
                post_data.pop('provider_id', None)
                post_data['password1'] = post_data['password2'] = password
                new_user = CustomUserCreationForm(post_data)
                if new_user.is_valid():
                    user = new_user.save(commit=False)
                    user.username = user.email
                    user.is_provider = True
                    user.save()

                    # Link the provider to the account that was just created and change their status to approved
                    provider.user_login = user
                    provider.is_approved = True
                    provider.save()

                    messages.success(request, 'Provider approved, account successfully created.')
                else:
                    messages.error(request, 'Provider account could not be created, please manually create an account'
                                            ' using the admin portal')
        elif post_data['action'] == 'reject':
            provider.delete()
            messages.success(request, 'Provider successfully rejected')

    providers = Provider.objects.filter(is_approved=False)
    context = {'providers': providers,
               'title': 'Account Requests'}

    return render(request, 'account/provider_requests.html', context)


@require_http_methods(['GET', 'POST'])
def provider_register(request):
    if request.method == 'POST':
        post_data = request.POST.copy()
        post_data['postal_code'] = post_data['postal_code'].replace(' ', '')
        provider = ProviderForm(post_data)

        if provider.is_valid():
            provider.save()
            messages.success(request, 'Your request has been successfully submitted. You will receive an email with '
                                      'your account details once your registration has been approved.')
            return redirect('account:login')
        else:
            provider_form = provider
            messages.error(request, 'There was an error with your form, '
                                    'please contact the administrator to request registration.')
    else:
        provider_form = ProviderForm()
    context = {'form': provider_form,
               'title': 'Register'}
    return render(request, 'account/provider_register.html', context)
