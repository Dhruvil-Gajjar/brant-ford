from django.urls import re_path as url 
from django.urls import include, path
from . import views

app_name = 'account'

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.provider_register, name='provider_register'),
    path('provider/requests', views.provider_requests, name='provider_requests'),
    url('', include('django.contrib.auth.urls')),
]
