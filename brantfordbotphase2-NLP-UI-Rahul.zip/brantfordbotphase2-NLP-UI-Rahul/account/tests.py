from django.test import TestCase
from account.tasks import send_message_visito
# Create your tests here.

send_message_visito.delay("9904992737", "123456")
