from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.forms import ModelForm

from account.models import Provider, CustomUser


class CustomUserCreationForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = CustomUser
        fields = ('email',)


class ProviderForm(ModelForm):
    class Meta:
        model = Provider
        exclude = ('is_approved', 'user_login')
        widgets = {'provider_id': forms.TextInput(attrs={'class': 'form-control'}),
                   'speciality_code': forms.Select(attrs={'class': 'form-control'}),
                   'clinical_role': forms.Select(attrs={'class': 'form-control'}),
                   'name': forms.TextInput(attrs={'class': 'form-control'}),
                   'first_name': forms.TextInput(attrs={'class': 'form-control'}),
                   'middle_name': forms.TextInput(attrs={'class': 'form-control'}),
                   'last_name': forms.TextInput(attrs={'class': 'form-control'}),
                   'business_name': forms.TextInput(attrs={'class': 'form-control'}),
                   'street': forms.TextInput(attrs={'class': 'form-control'}),
                   'city': forms.TextInput(attrs={'class': 'form-control'}),
                   'province': forms.Select(attrs={'class': 'form-control'}),
                   'postal_code': forms.TextInput(attrs={'class': 'form-control'}),
                   'phone': forms.TextInput(attrs={'class': 'form-control'}),
                   'fax': forms.TextInput(attrs={'class': 'form-control'}),
                   'email': forms.TextInput(attrs={'class': 'form-control'}),
                   'hst': forms.TextInput(attrs={'class': 'form-control'}),
                   'facility': forms.TextInput(attrs={'class': 'form-control'}),
                   'license1': forms.TextInput(attrs={'class': 'form-control'})}
