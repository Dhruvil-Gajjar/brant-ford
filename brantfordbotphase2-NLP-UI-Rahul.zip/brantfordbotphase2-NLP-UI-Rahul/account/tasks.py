import random
from twilio.rest import Client
from django.conf import settings
from django.core.mail import EmailMultiAlternatives, get_connection

from visito.celery import app


def generate_otp():
    fixed_digits = 6
    return random.randrange(111111, 999999, fixed_digits)


@app.task()
def send_email_visito(mail_subject, mail_body, mail_attachment, to_email):
    try:
        connection = get_connection(fail_silently=False)

        email = EmailMultiAlternatives(
            subject=mail_subject,
            body=mail_body,
            from_email=settings.EMAIL_HOST_USER,
            to=[to_email],
            connection=connection
        )
        email.attach_alternative(mail_attachment, "text/html")
        email.send()

        print('#### >>>>>>>>>>>>>>>>>>>>>>>> Email has been sent successfully to %s !!' % to_email)
    except Exception as err:
        print('#### >>>>>>>>>>>>>>>>>>>>>>>> Error in sending email to %s.' % to_email)
        print(err)


@app.task()
def send_message_visito(to_number, otp):
    try:
        client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)

        message = client.messages.create(
            to=f"+91{to_number}",
            from_="+14847499099",
            body=f"{otp} is your OTP for signing up. Never share OTP.",
        )
        print('#### >>>>>>>>>>>>>>>>>>>>>>>> Otp has been sent successfully to %s !!' % to_number)
    except Exception as err:
        print('#### >>>>>>>>>>>>>>>>>>>>>>>> Error in sending otp to %s.' % to_number)
        print(err)
