from django import template
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import redirect, render
from django.urls import reverse
from django.template import loader
from nlp.models import Intent, Section, Question, GroupInfo
from django.forms.models import model_to_dict
import json
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
import datetime
def get_intents():
    intents = json.dumps([model_to_dict(obj) for obj in Intent.objects.all()])
    return intents

def get_sections():
    sections = json.dumps([model_to_dict(obj) for obj in Section.objects.all()]) 
    return sections

def get_questions():
    questions = json.dumps([model_to_dict(obj, fields=['question_id','intent_id', 'question_text' ]) for obj in Question.objects.all()])
    return questions

@login_required
@csrf_exempt
def question_creation(request):
    print(request.COOKIES.get('sessionid'))
    has_follow_up = 0
    if request.method == "POST":
        print("Gotchaaa", json.loads(request.body.decode('UTF-8')))
        # try:
        resp = json.loads(request.body.decode('UTF-8'))
        if resp.get('responseList'):
            resp = resp.get('responseList')[0]
        else:
            message = "Failure"
            return HttpResponse(json.dumps({'message': message}))
        print(resp)
        sec_id = resp.get("section_id")
        print('sec_id====', sec_id)
        sec_name = resp.get("section_name")
        int_id = resp.get("intent_id")
        int_name = resp.get("intent_name")
        quest_id = resp.get("question_id")
        has_follow_up = resp.get("follow_up")
        # quest_name = resp.get('question_name')
        # question_type = resp.get('question_type')
        # max_characters_for_answer = resp.get('max_characters_for_answer')
        if sec_id == -1:
            if Section.objects.filter(section_name=sec_name).exists():
                sec_id  =  Section.objects.filter(section_name=sec_name).values_list('pk', flat=True)[0]
            else:
                new_sec = Section(section_name =sec_name)
                new_sec.save()
                sec_id = new_sec.section_id

        if int_id == -1:
            if Intent.objects.filter(intent_name=int_name,section_id_id=sec_id).exists():
                # int_id  =  Intent.objects.filter(intent_name=int_name,section_id_id=sec_id).values_list('pk', flat=True)[0]
                new_int  =  Intent.objects.filter(intent_name=int_name,section_id_id=sec_id)[0]
            else:
                new_int = Intent(intent_name = int_name, section_id_id = sec_id)
                new_int.save()
                # int_id = new_int.intent_id
        else:
            new_int = Intent.objects.filter(intent_id = int_id)[0]

        if quest_id != -1:
            old_ques = Question.objects.get(question_id=quest_id)
            old_ques.session_id = resp.get("session_id")
            old_ques.timestamp = datetime.datetime.fromtimestamp(resp.get('date_time') / 1e3)
            old_ques.save()
            # intents = get_intents()
            # sections = get_sections()
            # questions = get_questions()
            # context = {'segment': 'question_creation',"intents": intents, 'questions': questions, 'sections': sections, 'sessionId':request.COOKIES.get('sessionid'), "follow_up": has_follow_up}
            message = "Success"
            # html_template = loader.get_template('nlp/question_creation.html')
            # return render(request, "nlp/question_creation.html", context)
            # return HttpResponseRedirect(html_template.render(context, request))
            return HttpResponse(json.dumps({'message': message, "follow_up": has_follow_up}))

        new_quest = Question(intent_id = new_int, question_text = resp.get('question_name'), question_type = resp.get('question_type'), question_order = resp.get("question_order"), answer_length = resp.get('max_characters_for_answer'), age_restriction = resp.get('age_restricted'), age_range_lower=resp.get('age_lower_bound'), age_range_upper= resp.get('age_upper_bound'), choices = resp.get('choices'), report_text = resp.get('report_text'), sex_restriction = resp.get('sex_restriction'), sex = resp.get('sex_restricted_to'), repeat_restriction = resp.get('repeat_restriction'), repeat_days = resp.get('repeat_days'),session_id = resp.get("session_id"),timestamp = datetime.datetime.fromtimestamp(resp.get('date_time') / 1e3))
        # resp.get('session_id')
        # resp.get('dateTime')
        new_quest.save()
        message = "Success"
        # intents = get_intents()
        # sections = get_sections()
        # questions = get_questions()
        # context = {'segment': 'question_creation',"intents": intents, 'questions': questions, 'sections': sections, 'sessionId':request.COOKIES.get('sessionid'), "follow_up": has_follow_up}
        # html_template = loader.get_template('nlp/question_creation.html')
        # return HttpResponseRedirect(html_template.render(context, request))
        # return render(request, "nlp/question_creation.html", context)
        return HttpResponse(json.dumps({'message': message, "follow_up": has_follow_up}))

        # except Exception as e:
        #     message = "Failure"
        #     print(str(e))
        #     return HttpResponse(json.dumps({'message': message}))

    intents = get_intents()
    sections = get_sections()
    questions = get_questions()
    # print(questions)
    context = {'segment': 'page_loading',"intents": intents, 'questions': questions, 'sections': sections, 'sessionId':request.COOKIES.get('sessionid'), "follow_up": has_follow_up}
    # html_template = loader.get_template('nlp/question_creation.html')
    # return HttpResponse(html_template.render(context, request))
    return render(request, "nlp/question_creation.html", context)



# segment_questions = Question.objects.filter(intent_id=self.intent_id, question_order=self.question_order,
#                                                     question_order__gte=0).exclude(question_id=self.question_id) \
#             .exclude(intent_id__intent_name='Grouped')


@login_required
@csrf_exempt
def group_creation(request):
    resp = json.loads(request.body.decode('UTF-8'))
    try:
        group_name = resp.get('groupName')
        session_key = resp.get('sessionId')
        print(group_name, session_key)
        new_group = GroupInfo(group_name = group_name, session_key = session_key)
        new_group.save()
        message = "Success"
        return HttpResponse(json.dumps({'message': message}))
    except Exception as e:
        print(resp, str(e))
        message = "Failure"
        return HttpResponse(json.dumps({'message': message}))
