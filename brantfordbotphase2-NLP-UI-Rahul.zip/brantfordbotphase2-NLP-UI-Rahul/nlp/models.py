
import re
from itertools import groupby

from django.core.exceptions import ValidationError
from django.core.validators import EMPTY_VALUES, MinValueValidator
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
import datetime

# Create your models here.
class ChatInfo(models.Model):
    MALE = 'M'
    FEMALE = 'F'
    OTHER = 'O'
    PREFER_NOT_TO_DISCLOSE = 'U'

    SEX_CHOICES = [
        (MALE, 'Male'),
        (FEMALE, 'Female'),
        (OTHER, 'Other'),
        (PREFER_NOT_TO_DISCLOSE, 'Prefer not to say')
    ]

    chat_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=250)
    email_address = models.CharField(max_length=250)
    date_of_birth = models.DateField()
    sex = models.CharField(max_length=18, choices=SEX_CHOICES)
    first_visit = models.BooleanField(default=True)
    registration_form = models.BooleanField(default=False)
    clinical_form = models.BooleanField(default=False)
    responded = models.BooleanField(default=False)
    chat_ended = models.DateTimeField()

    @staticmethod
    def get_latest_chat_info_for_patient(patient):
        if patient is None:
            return None
        latest = ChatInfo.objects.filter(email_address=patient.email,
                                         date_of_birth=patient.date_of_birth).order_by('-chat_ended').first()
        return latest

    @staticmethod
    def get_last_answered(patient, question):
        if None in [patient, question]:
            return None
        patient_name = f'{patient.first_name.lower()} {patient.last_name.lower()}'
        chats_for_patient = ChatInfo.objects.filter(email_address=patient.email,
                                                    date_of_birth=patient.date_of_birth,
                                                    name=patient_name,
                                                    sex=patient.gender).values_list('chat_id', flat=True)

        latest = Response.objects.filter(chat_id__in=chats_for_patient,
                                         question_id=question).order_by('chat_id__chat_ended').first()
        return latest


class Section(models.Model):
    section_id = models.AutoField(primary_key=True)
    section_name = models.CharField(max_length=250)

    def __str__(self):
        return str(self.section_name)


class Intent(models.Model):
    intent_id = models.AutoField(primary_key=True)
    section_id = models.ForeignKey(Section, on_delete=models.CASCADE)
    intent_name = models.CharField(max_length=250)

    def __str__(self):
        return f'{" ".join(self.intent_name.split("_")).title()}'


class GroupInfo(models.Model):
    group_id = models.AutoField(primary_key=True)
    group_name = models.CharField(max_length=250)
    group_for_each = models.CharField(max_length=250, null=True)
    session_key = models.CharField(max_length=250)

    def __str__(self):
        return f"{str(self.group_name)} - {str(self.session_key)}"


class Question(models.Model):
    class QuestionType(models.IntegerChoices):
        TEXT = 1
        INTEGER = 2
        BOOLEAN = 3
        SINGLE_SELECT = 4
        MULTIPLE_SELECT = 5
        CHECKBOX = 6
        DROPDOWN = 7
        DATETIME = 8
        DATE = 9
        TIME = 10

        SINGLE_SELECT_POSITIVE = 11
        SINGLE_SELECT_NEGATIVE = 12
        MULTIPLE_SELECT_POSITIVE = 13
        MULTIPLE_SELECT_NEGATIVE = 14
        SINGLE_SELECT_POSITIVE_NEGATIVE = 15
        MULTI_SELECT_POSITIVE_NEGATIVE = 16
        SINGLE_SELECT_POSITIVE_NEGATIVE_NOA = 17
        MULTI_SELECT_POSITIVE_NEGATIVE_NOA = 18

        MULTIPLE_DROPDOWN = 19
        TEXT_AND_DROPDOWN = 20
        INTEGER_AND_DROPDOWN = 21
        INTEGER_RANGE_AND_DROPDOWN = 22

        INTEGER_RANGE = 23
        # segment header  and footer questions
        SEGMENT = 24
        # segment header  and footer questions
        TEXT_SEGMENT = 25

    class DetailLevel(models.IntegerChoices):
        LITTLE = 0
        MEDIUM = 1
        MAX = 2

    # question attributes
    question_id = models.AutoField(primary_key=True)
    intent_id = models.ForeignKey(Intent, on_delete=models.CASCADE)
    question_text = models.CharField(max_length=500)
    question_type = models.IntegerField(choices=QuestionType.choices)
    session_id = models.CharField(max_length=100, null=False)
    timestamp = models.DateTimeField(default=datetime.datetime.now())
    follow_up = models.BooleanField(
        default=False, verbose_name='has follow up')
    report_text = models.CharField(max_length=500)
    age_restriction = models.BooleanField()
    age_range_lower = models.IntegerField(null=True, blank=True)
    age_range_upper = models.IntegerField(null=True, blank=True)
    sex_restriction = models.BooleanField()
    sex = models.CharField(
        max_length=18, choices=ChatInfo.SEX_CHOICES, null=True, blank=True)
    repeat_restriction = models.BooleanField(default=False)
    repeat_days = models.IntegerField(default=0, null=True, blank=True)
    choices = models.CharField(max_length=500, null=True, blank=True)
    replace_yes = models.BooleanField(default=False)
    report_yes = models.CharField(max_length=50, null=True, blank=True)
    replace_no = models.BooleanField(default=False)
    report_no = models.CharField(max_length=50, null=True, blank=True)
    question_order = models.IntegerField(
        default=0, null=False, blank=False, validators=[MinValueValidator(-1)])
    question_sub_order = models.IntegerField(default=0, null=True, blank=True)
    detail_level = models.IntegerField(
        choices=DetailLevel.choices, default=DetailLevel.LITTLE, null=False, blank=False)
    answer_length = models.IntegerField(
        default=256, null=True, blank=True, validators=[MinValueValidator(1)])
    is_required = models.BooleanField(default=True)
    group_id = models.OneToOneField(GroupInfo, related_name='GroupInfo', on_delete=models.CASCADE, null=True,
                                    blank=True)

    def __str__(self):
        return f'{self.question_id}: {self.question_text}'

    def to_json(self):
        json_dict = {'question_id': self.question_id,
                     'question_type': self.question_type,
                     'question_text': self.question_text,
                     'question_order': self.question_order,
                     'question_sub_order': self.question_sub_order,
                     'required': self.is_required,
                     'has_follow_up': self.follow_up
                     }
        if self.question_type in [4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 20, 21]:
            json_dict['choices'] = self.choices_as_list()
        elif self.question_type == 23:
            json_dict['choices'] = self.integer_range()
        elif self.question_type == 22:
            json_dict['choices'] = self.integer_range_and_dropdown_as_list()

        if self.answer_length:
            json_dict['answer_length'] = self.answer_length

        # If length of any single select options is less than 4, change question type to single select (radio buttons)
        # rather than dropdown
        if self.question_type in [11, 12, 15, 17] and len(json_dict['choices']) <= 3:
            json_dict['question_type'] = 4

        # Get questions for group if there is a group question
        if self.group_id:
            # Excludes follow up questions
            questions_for_group = GroupQuestion.objects.filter(group_id=self.group_id) \
                .order_by('question_order', 'question_id__question_order').exclude(question_id__question_order=-1)
            group_question_list = []
            for question in questions_for_group:
                group_question_dict = {'question_id': question.question_id.question_id,
                                       'question_type': question.question_id.question_type,
                                       'question_text': question.question_id.question_text,
                                       'required': question.question_id.is_required,
                                       'has_follow_up': question.question_id.follow_up}

                if question.question_id.question_type in [4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 20, 21]:
                    group_question_dict['choices'] = question.question_id.choices_as_list(
                    )
                elif question.question_id.question_type == 23:
                    group_question_dict['choices'] = question.question_id.integer_range(
                    )
                elif question.question_id.question_type == 22:
                    group_question_dict['choices'] = question.question_id.integer_range_and_dropdown_as_list(
                    )

                group_question_list.append(group_question_dict)

            json_dict['questions_for_group'] = group_question_list
            json_dict['group_name'] = self.group_id.group_name

        return json_dict

    @staticmethod
    def get_follow_up_questions(question_list, follow_up_questions):
        if len(question_list) == 0:
            formatted_follow_ups = []
            for question in follow_up_questions:
                formatted_question = question.follow_up_question_id.to_json()
                formatted_question['follow_up_option'] = question.option
                formatted_question['original_question'] = question.question_id.question_id
                formatted_follow_ups.append(formatted_question)
            return formatted_follow_ups
        else:
            question_ids = [question.question_id for question in question_list if question.follow_up]
            new_follow_ups = FollowUpQuestion.objects.select_related('follow_up_question_id').\
                filter(question_id__in=question_ids)
            for question in new_follow_ups:
                if question not in follow_up_questions:
                    follow_up_questions.append(question)

            new_follow_ups = [new_question.follow_up_question_id for new_question in new_follow_ups]
            return Question.get_follow_up_questions(new_follow_ups, follow_up_questions)

    def clean(self, *args, **kwargs):
        # Validate conditions
        if self.sex_restriction:
            if self.sex in EMPTY_VALUES:
                raise ValidationError(
                    {'sex': _('Sex must be chosen if sex restriction is selected')})

        if self.age_restriction:
            if self.age_range_lower in EMPTY_VALUES and self.age_range_upper in EMPTY_VALUES:
                raise ValidationError({'age_restriction': _('Age range lower and/or Age range upper must be filled '
                                                            'in if age restriction is selected')})

        if self.repeat_restriction:
            if self.repeat_days in EMPTY_VALUES:
                raise ValidationError({'repeat_days': _('Repeat days must be filled in if repeat restriction is '
                                                        'selected')})

        # Validate that choices field must be filled in for selection questions
        if self.question_type in [4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23]:
            if self.choices in EMPTY_VALUES:
                raise ValidationError(
                    {'choices': _('Choices cannot be empty for the selected question type')})

            if self.question_type != 23:
                # Validate that choices for single/multiple selects must be separated by commas and contain more than one value
                choices_list = self.choices.split(',')
                choices_list = [choice.strip()
                                for choice in choices_list if choice.strip()]

                if len(choices_list) < 2:
                    raise ValidationError({'choices': _('More than one choice must be entered. Each choice should be '
                                                        'separated by a comma. Eg. Option 1, Option 2, Option 3')})

                # Validate that the choices are unique
                duplicate_choices = self.find_duplicate_choices(choices_list)
                if len(duplicate_choices) > 0:
                    raise ValidationError({'choices': _(f'There are duplicate choices in the list: '
                                                        f'{", ".join(duplicate_choices)}.')})

                # Validate that the integer range and dropdown choices are in the correct format
                if self.question_type == 22:
                    invalid_choices = []
                    for choice in choices_list:
                        search = re.search(r'(.*?\[\d*?\/\d*?\])', choice)
                        if not search:
                            invalid_choices.append(choice)
                    if len(invalid_choices) > 0:
                        raise ValidationError({'choices': _(f'For Integer Range and Dropdown questions, the format '
                                                            f'for each choice must be choice[lower range/upper range], '
                                                            f'eg. Option 1[0/50].The following choices are not valid: '
                                                            f'{", ".join(invalid_choices)}')})

            else:
                # Validate integer range choice is in the correct format
                choice = re.search(r'\[(\d*?\/\d*?)\]', self.choices)
                if not choice:
                    raise ValidationError({'choices': _('For Integer Range questions, the format for choices must be '
                                                        '[lower range/upper range], eg. [0/50]')})

        # Validate that group question must be an integer range type
        if self.group_id and self.question_type != 23:
            raise ValidationError({'question_type': _(
                'Group questions must be have question type of integer range')})

        # Validate that a follow up question must be boolean/single/multiple select type
        if self.follow_up and self.question_type not in [3, 4, 5, 6, 7, 11, 12, 13, 14, 15, 16, 17, 18]:
            raise ValidationError({'follow_up': _(f'Question type {self.get_question_type_display()} cannot have '
                                                  f'follow up questions.')})

        # Validate that group question cannot be follow up questions
        if self.group_id and self.question_order == -1:
            raise ValidationError({'question_type': _(f'Group questions cannot be used as a follow up '
                                                      f'question with question order -1')})

        # Validate segment questions order/suborder
        if self.question_type == 24:
            if self.question_sub_order != 0:
                raise ValidationError({'question_sub_order': _('For segment questions, the question suborder must be '
                                                               '0')})

        # Find questions that have the same question order as this question
        segment_questions = Question.objects.filter(intent_id=self.intent_id, question_order=self.question_order,
                                                    question_order__gte=0).exclude(question_id=self.question_id) \
            .exclude(intent_id__intent_name='Grouped')

        if len(segment_questions) > 0:
            segment_title = segment_questions.filter(question_type=24).first()
            # Validate that a segment question type exists if you're adding a question with the same order as another
            if not segment_title and self.question_type != 24:
                raise ValidationError({'question_order': _(f'Question with question order {self.question_order} '
                                                           f'cannot be added without a segment question with '
                                                           f'the same question order')})

            # Validate you cannot add another segment question to a segment question
            if segment_title and self.question_type == 24:
                raise ValidationError({'question_type': _('Another segment question cannot be added to an already '
                                                          'existing segment')})
            # Validate you cannot add a group question to a segment question
            if segment_title and self.group_id:
                raise ValidationError(
                    {'group_id': _('A group question cannot be added to a segment question')})
            # Validate suborder is filled for a segment question
            if self.question_sub_order in EMPTY_VALUES:
                raise ValidationError({'question_sub_order': _('Suborder must be filled out for questions part of a '
                                                               'segment. If this question is not part of a segment, '
                                                               'check that the question order is not the same as '
                                                               'any existing questions in this intent')})

            # Validate that the suborder of the segment questions are unique
            if self.question_sub_order in segment_questions.values_list('question_sub_order', flat=True):
                raise ValidationError({'question_sub_order': _(f'A question with suborder {self.question_sub_order} '
                                                               f'already exists for this segment. Question sub '
                                                               f'orders must be unique for segment questions')})
        super(Question, self).clean()

    @staticmethod
    def find_duplicate_choices(choices_list):
        duplicates = set()
        unique_choices = set()
        for choice in choices_list:
            lower_choice = choice.lower()
            if lower_choice not in unique_choices:
                unique_choices.add(lower_choice)
            else:
                duplicates.add(choice)
        return duplicates

    @staticmethod
    def aggregate_questions_by_order(questions):
        aggregated_questions = []
        for order, question_list in groupby(questions, key=lambda x: x['question_order']):
            # Don't aggregate follow up questions (question order = -1)
            if order != -1:
                # Remove questions order and suborder as we don't need them anymore
                lst = [{key: value for key, value in d.items() if key not in ['question_order', 'question_sub_order']}
                       for d in list(question_list)]
                if len(lst) > 1:
                    segment = lst[0]
                    segment['segment_questions'] = lst[1:]
                    aggregated_questions.append(segment)
                else:
                    # Don't add the question if it's a segment question with no other questions
                    if lst[0]['question_type'] != 24:
                        aggregated_questions.append(lst[0])

        return aggregated_questions

    @staticmethod
    def filter_questions(question_list, patient, detail_level):
        filtered_questions = []
        for question in question_list:
            # Filter by age
            if question.age_restriction:
                if question.age_range_lower and question.age_range_upper:
                    if not question.age_range_lower <= patient.get_age() <= question.age_range_upper:
                        continue
                elif question.age_range_lower:
                    if patient.get_age() < question.age_range_lower:
                        continue
                elif question.age_range_upper:
                    if patient.get_age() > question.age_range_upper:
                        continue

            # Filter by gender
            if question.sex_restriction and (question.sex != patient.gender):
                continue

            # Filter by detail level
            if question.detail_level > Question.DetailLevel(int(detail_level)):
                continue

            # Filter out repeat questions
            if question.repeat_restriction:
                last_answered = ChatInfo.get_last_answered(patient, question)
                if last_answered:
                    date_difference = timezone.now() - last_answered.chat_id.chat_ended
                    if date_difference.days < question.repeat_days:
                        continue

            filtered_questions.append(question)

        return filtered_questions

    def save(self, *args, **kwargs):
        self.full_clean()
        super(Question, self).save(*args, **kwargs)

    def choices_as_list(self):
        return [choice.strip() for choice in self.choices.split(',')]

    def integer_range(self):
        int_range_search = re.search(r'\[(\d*?\/\d*?)\]', self.choices)
        if int_range_search:
            int_range = {}
            split = int_range_search.group(0).strip('[]').split('/')
            int_range['lower'] = int(split[0])
            int_range['upper'] = int(split[1])
            return int_range
        else:
            return None

    def integer_range_and_dropdown_as_list(self):
        choices = self.choices_as_list()
        choice_dict = {}
        for choice in choices:
            search = re.search(r'(.*?)(\[\d*?\/\d*?\])', choice)
            if search.group():
                split = search.group(2).strip('[]').split('/')
                choice_dict[search.group(1)] = {'lower': int(split[0]),
                                                'upper': int(split[1])
                                                }
        return choice_dict


class FollowUpQuestion(models.Model):
    follow_up_id = models.AutoField(primary_key=True)
    question_id = models.ForeignKey(
        Question, related_name='FollowUpQuestion', on_delete=models.CASCADE, verbose_name='original question')
    option = models.CharField(max_length=250)
    follow_up_question_id = models.ForeignKey(
        Question, on_delete=models.CASCADE)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['follow_up_question_id', 'option', 'question_id'],
                                    name='unique_follow_up_question_option')
        ]

    def __str__(self):
        return str(self.question_id)

    def clean(self, *args, **kwargs):
        # Validate that question id must be a follow up question
        if not self.question_id.follow_up:
            raise ValidationError({'question_id': _(
                f'The selected question must be marked as follow up question.')})

        # Validate the question order for the follow up question id is -1
        if self.follow_up_question_id.question_order != -1:
            raise ValidationError({'follow_up_question_id': _(f'The selected follow up question must have question '
                                                              f'order of -1.')})

        # Validate that the question and its follow up question are in the same intent
        if self.question_id.intent_id != self.follow_up_question_id.intent_id:
            raise ValidationError({'question_id': _(f'The intent for the question id must be the same as the '
                                                    f'intent for the follow up question id. The question id intent is '
                                                    f'{self.question_id.intent_id} and the follow up question id '
                                                    f'intent is {self.follow_up_question_id.intent_id}')})

        # If boolean, validate option should be 1 or 0 (yes/no)
        if self.question_id.question_type == 3 and self.option not in ["yes", "no"]:
            raise ValidationError({'option': _(
                f'The option for a boolean follow up question should be yes or no.')})

        # If single/multiple select, validate that option exists for the question id
        if self.question_id.question_type != 3 and self.option not in self.question_id.choices_as_list():
            raise ValidationError({'option': _(f'The option does not match any of the options for the selected '
                                               f'question. This field is case sensitive and the spaces must match. '
                                               f' Must be one of '
                                               f'{", ".join(self.question_id.choices_as_list())}.')})

        # Validate that the follow up question has not been used already
        existing_follow_up = FollowUpQuestion.objects.filter(follow_up_question_id=self.follow_up_question_id).\
            exclude(follow_up_id=self.follow_up_id).first()
        if existing_follow_up:
            raise ValidationError({'follow_up_question_id': _(f'The selected follow up question is already being used '
                                                              f'for question id {existing_follow_up.question_id}. '
                                                              f'Please select or create a different follow up '
                                                              f'question.')})

        super(FollowUpQuestion, self).clean()

    def save(self, *args, **kwargs):
        self.full_clean()
        super(FollowUpQuestion, self).save(*args, **kwargs)


class GroupQuestion(models.Model):
    group_question_id = models.AutoField(primary_key=True)
    group_id = models.ForeignKey(
        GroupInfo, on_delete=models.CASCADE, db_index=True)
    question_id = models.ForeignKey(
        Question, on_delete=models.CASCADE, db_index=True)
    question_order = models.IntegerField(default=0, null=True, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['group_id', 'question_id'], name='unique_group_question')
        ]

    def __str__(self):
        return str(self.question_id.question_text)

    def clean(self, *args, **kwargs):
        if self.question_id.question_type == 24:
            raise ValidationError(
                {'question_id': _('Segment question type cannot be added to group question')})

        if self.question_id.group_id:
            raise ValidationError({'question_id': _('A group question type cannot be added to another group '
                                                    'question')})

        super(GroupQuestion, self).clean()

    def save(self, *args, **kwargs):
        self.full_clean()
        super(GroupQuestion, self).save(*args, **kwargs)


class Response(models.Model):
    answer_id = models.AutoField(primary_key=True)
    chat_id = models.ForeignKey(ChatInfo, on_delete=models.CASCADE)
    question_id = models.ForeignKey(Question, on_delete=models.CASCADE)
    answer = models.CharField(max_length=500, null=True, blank=True)
    group_item_number = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return str(self.answer)


class PatientForm(models.Model):
    FORM_TYPES = [
        ('registration', 'registration'),
        ('clinical', 'clinical')
    ]

    form_id = models.AutoField(primary_key=True)
    form_name = models.CharField(max_length=500)
    form_type = models.CharField(max_length=12, choices=FORM_TYPES)
    age_range_lower = models.IntegerField(null=True, blank=True)
    age_range_upper = models.IntegerField(null=True, blank=True)
    form_url = models.CharField(max_length=500)

    def __str__(self):
        return str(self.form_name)
