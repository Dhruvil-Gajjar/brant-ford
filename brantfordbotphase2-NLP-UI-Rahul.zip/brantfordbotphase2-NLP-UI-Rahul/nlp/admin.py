from django.contrib import admin
from django_admin_listfilter_dropdown.filters import DropdownFilter, RelatedDropdownFilter

from nlp.models import *

# Register your models here.


class ChatInfoAdmin(admin.ModelAdmin):
    list_display = ('chat_id', 'registration_form',
                    'clinical_form', 'responded')


class IntentAdmin(admin.ModelAdmin):
    list_filter = (
        ('section_id', RelatedDropdownFilter),
    )


class QuestionAdmin(admin.ModelAdmin):
    list_filter = (
        ('intent_id', RelatedDropdownFilter),
    )
    list_display = ('question_text', 'question_order',
                    'question_sub_order')


class PatientFormAdmin(admin.ModelAdmin):
    list_filter = (
        ('form_type', DropdownFilter),
    )


class GroupInfoFormAdmin(admin.ModelAdmin):
    list_display = ('group_id', 'group_name')


class GroupQuestionFormAdmin(admin.ModelAdmin):
    list_display = ('group_id', 'question_id')


class Follow_Up_QuestionFormAdmin(admin.ModelAdmin):
    list_display = ('question_id', 'option', 'follow_up_question_id')


admin.site.register(ChatInfo, ChatInfoAdmin)
admin.site.register(Section)
admin.site.register(Intent, IntentAdmin)
admin.site.register(Question, QuestionAdmin)
admin.site.register(Response)
admin.site.register(PatientForm, PatientFormAdmin)
admin.site.register(GroupInfo, GroupInfoFormAdmin)
admin.site.register(FollowUpQuestion, Follow_Up_QuestionFormAdmin)
admin.site.register(GroupQuestion, GroupQuestionFormAdmin)
