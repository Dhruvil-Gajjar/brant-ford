from django.apps import AppConfig


class NlpConfig(AppConfig):
    name = 'nlp'
