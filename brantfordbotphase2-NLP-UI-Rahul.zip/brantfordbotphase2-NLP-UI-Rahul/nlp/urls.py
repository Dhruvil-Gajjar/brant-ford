from django.urls import re_path as url
from django.urls import path, re_path
from nlp import views

app_name = 'nlp'

urlpatterns = [
    path('qa', views.question_creation, name='question_creation'),
    path('group', views.group_creation, name="group_creation"),
]
