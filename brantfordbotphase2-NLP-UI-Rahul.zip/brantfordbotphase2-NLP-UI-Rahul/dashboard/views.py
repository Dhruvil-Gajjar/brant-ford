import os
from visito import settings
from django.shortcuts import render
from django.shortcuts import redirect
from django.conf import settings
from django.http import HttpResponse, Http404
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime
from pytz import timezone
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.core.mail import EmailMultiAlternatives
from dateutil import relativedelta
from django.utils import timezone
import pytz
from nlp.models import *
from nlp.models import GroupQuestion
import xml.etree.ElementTree as ET
from django.core.exceptions import ObjectDoesNotExist
from account.tasks import send_email_visito
# Create your views here.

in_use_model = None


@csrf_exempt
def user_chats(request, name, email, sex, date_of_birth):
    if request.user.is_authenticated and request.user.is_superuser:
 
        chats = ChatInfo.objects.filter(name__iexact=name.lower(), email_address=email, sex=sex,
                                        date_of_birth=date_of_birth).order_by('-chat_ended')
        # Get inquiries
        inquiries = Intent.objects.filter(
            section_id__section_name='inquiries').values_list('intent_name', flat=True)

        reports = []
        for chat in chats:
            report = get_report2(chat.chat_id)
            reports.append(report)
        context = {"chats": chats, "reports": reports, "inquiries": inquiries}

        return render(request=request, template_name="dashboard/user_chats.html", context=context)
    else:
        return redirect('account:login')


def get_user_list(request):
    if request.user.is_authenticated and request.user.is_superuser:
        if request.method == 'POST':
            email_id = request.POST.get('email')
            name = request.POST.get('name')

            if email_id == "":

                user_list = ChatInfo.objects.filter(name__iexact=name.lower()).values('name', 'email_address', 'sex',
                                                                                      'date_of_birth').order_by(
                    '-chat_ended').distinct()
            else:

                user_list = ChatInfo.objects.filter(email_address=email_id).values('name', 'email_address', 'sex',
                                                                                   'date_of_birth').order_by(
                    '-chat_ended').distinct()
            context = {"users_list": user_list}

            return render(request=request, template_name="dashboard/user_chats.html", context=context)
        else:
            return render(request=request, template_name="dashboard/user_chats.html")
    else:
        return redirect('account:login')


def get_report(chat_id):
    user_info = ChatInfo.objects.get(chat_id=chat_id)

    # Retrieve answers
    answers = Response.objects.filter(chat_id=chat_id)

    report_answers = {}
    for answer in answers:
        if answer.question_id.intent_id.intent_name not in report_answers.keys():
            report_answers[answer.question_id.intent_id.intent_name] = []
        text = answer.question_id.report_text.replace(
            '{{answer}}', answer.answer)
        report_answers[answer.question_id.intent_id.intent_name].append(text)

    # Add to context
    report = {'chat_id': chat_id,
              'user_info': user_info,
              'answers': report_answers}

    return report


def get_report2(chat_id):
    # Retrieve user info
    user_info = ChatInfo.objects.get(chat_id=chat_id)
    print(user_info.chat_ended)
    fmt = '%Y-%m-%d %H:%M:%S %Z%z'
    year = user_info.chat_ended.year
    month = user_info.chat_ended.month
    day = user_info.chat_ended.day
    hour = user_info.chat_ended.hour
    minute = user_info.chat_ended.minute
    second = user_info.chat_ended.second

    utc = pytz.utc
    new_datetime_obj = datetime(
        year, month, day, hour, minute, second, tzinfo=utc)

    est = pytz.timezone('US/Eastern')

    time_est = new_datetime_obj.astimezone(est)
    user_info.chat_ended = time_est
    print(user_info.chat_ended)

    user_age = calculate_age(user_info.date_of_birth)
    # Retrieve answers
    answers = Response.objects.filter(chat_id=chat_id)

    # Retrieve all "inquiry" intent items, so we know to format these items line by line rather than in paragraph
    inquiries = Intent.objects.filter(
        section_id__section_name='inquiries').values_list('intent_name', flat=True)

    # Replace {{answer}} in report text with answers from chat
    report_answers = {}
    for answer in answers:

        if answer.question_id.intent_id.intent_name.lower().strip() == 'grouped' and get_group_member(
                answer.question_id).strip() not in report_answers.keys():
            report_answers[get_group_member(
                answer.question_id).strip()] = []

        elif get_group_name(answer.question_id) is not None and get_group_name(answer.question_id) not in report_answers.keys():
            report_answers[get_group_name(answer.question_id)] = []

        elif answer.question_id.intent_id.intent_name not in report_answers.keys() and answer.question_id.intent_id.intent_name.lower().strip() != 'grouped':
            report_answers[answer.question_id.intent_id.intent_name] = []

        # Replace the {{answer}}/{{psitive}}/{{negative}} with the respective entries given by the user from the database upon the question type

        # question type:12 and 14 negative single and multiselect
        if answer.question_id.question_type == 12 or answer.question_id.question_type == 14:
            choices = answer.question_id.choices.split(',')
            multi_answers = answer.answer.split(',')
            negative_answers = [x for x in choices if x not in multi_answers]
            add_and_to_list(negative_answers)
            negative_answer = ', '.join(map(str, negative_answers))
            text = answer.question_id.report_text.replace(
                '{{negative}}', negative_answer)
        # question type:11 and 13 positive single and multiselect
        elif answer.question_id.question_type == 11 or answer.question_id.question_type == 13:
            multi_answers = answer.answer.split(',')
            add_and_to_list(multi_answers)
            positive_answer = ', '.join(multi_answers)
            text = answer.question_id.report_text.replace(
                '{{positive}}', positive_answer)
        # question type:15 and 16 postitive/negative for single and multiselect
        elif answer.question_id.question_type == 15 or answer.question_id.question_type == 16:
            choices = answer.question_id.choices.split(',')
            multi_answers = answer.answer.split(',')
            negative_answers = [x for x in choices if x not in multi_answers]
            add_and_to_list(negative_answers)
            add_and_to_list(multi_answers)
            negative_answer = ', '.join(map(str, negative_answers))
            text = answer.question_id.report_text.replace(
                '{{negative}}', negative_answer)
            positive_answer = ', '.join(multi_answers)
            text = text.replace('{{positive}}', positive_answer)
        # question type:17 and 18 postitive/negative with NOA for single and multiselect
        elif answer.question_id.question_type == 17 or answer.question_id.question_type == 18:
            choices = answer.question_id.choices.split(',')
            text = answer.question_id.report_text
            lower_text = text.lower()
            or_index = lower_text.index('or')
            positive_text = text[0: or_index - 1]
            negative_text = text[or_index + 2:len(text)]
            noa = choices.pop().lstrip().lower()

            if (answer.answer.lstrip().lower() == noa):
                add_and_to_list(choices)
                negative_answer = ', '.join(choices)
                text = negative_text.replace(
                    '{{negative}}', negative_answer)
            else:
                multi_answers = answer.answer.split(',')
                add_and_to_list(multi_answers)
                positive_answer = ', '.join(multi_answers)
                text = positive_text.replace('{{positive}}', positive_answer)
                negative_answer = ', '.join(choices)
                text = text.replace('{{negative}}', negative_answer)

        # If question is boolean, get the answer if replace yes/no is present
        elif answer.question_id.question_type == 3:
            text = answer.question_id.report_text
            if answer.question_id.replace_yes and answer.answer.lower() == 'yes':
                if answer.question_id.report_yes is None:
                    boolean_answer = ''
                else:
                    boolean_answer = answer.question_id.report_yes

            elif answer.question_id.replace_no and answer.answer.lower() == 'no':
                if answer.question_id.report_no is None:
                    boolean_answer = ''
                else:
                    boolean_answer = answer.question_id.report_no
            else:
                boolean_answer = answer.answer

            text = text.replace('{{answer}}', boolean_answer)
        else:
            multi_answers = answer.answer.split(',')
            add_and_to_list(multi_answers)
            positive_answer = ', '.join(multi_answers)
            text = answer.question_id.report_text.replace(
                '{{answer}}', positive_answer)
        
        # group item numbering
        text = text.replace('{{no}}', str(answer.group_item_number))

        segment_part = get_segment_part(
            answer.question_id.question_type, answer.question_id.question_sub_order)

        if answer.question_id.intent_id.intent_name.lower().strip() == 'grouped':

            report_answers[get_group_member(answer.question_id).strip()].append(
                [text, segment_part])

        elif get_group_name(answer.question_id) is None:
            report_answers[answer.question_id.intent_id.intent_name].append(
                [text, segment_part])
        else:
            report_answers[get_group_name(answer.question_id)].append(
                [text, segment_part])

    # Add everything to context
    report = {'chat_id': chat_id,
              'inquiries': inquiries,
              'user_info': user_info,
              'user_age': user_age,
              'answers': report_answers,
              }

    return report


def add_and_to_list(list):
    if len(list) > 1:
        last_item = list.pop()
        last_item = 'and ' + last_item
        list.append(last_item)


def report(request, chat_id):
    if request.user.is_authenticated and request.user.is_superuser:

        # Retrieve user info
        user_info = ChatInfo.objects.get(chat_id=chat_id)

        # Retrieve answers
        answers = Response.objects.filter(chat_id=chat_id)

        # Retrieve all "inquiry" intent items, so we know to format these items line by line rather than in paragraph
        # form
        inquiries = Intent.objects.filter(
            section_id__section_name='inquiries').values_list('intent_name', flat=True)

        # Replace {{answer}} in report text with answers from chat
        report_answers = {}
        for answer in answers:
            if answer.question_id.intent_id.intent_name not in report_answers.keys():
                report_answers[answer.question_id.intent_id.intent_name] = []

            # Replace the {{answer}} with the respective answer given by the user from the database
            if answer.question_id.question_type == 12 | answer.question_id.question_type == 14:
                choices = answer.question_id.choices.split(',')

                multi_answers = answer.answer.split(',')

                negative_answer = ', '.join(
                    map(str, [x for x in choices if x not in multi_answers]))
                text = answer.question_id.report_text.replace(
                    '{{answer}}', negative_answer)
            else:
                text = answer.question_id.report_text.replace(
                    '{{answer}}', answer.answer)

            # Replace the yes/no answers with their respective alternatives if they exist
            if answer.question_id.replace_yes:
                if answer.question_id.report_yes is None:
                    text = text.replace('yes', '')
                else:
                    text = text.replace('yes', answer.question_id.report_yes)

            if answer.question_id.replace_no:
                if answer.question_id.report_no is None:
                    text = text.replace('no', '')
                else:
                    text = text.replace('no', answer.question_id.report_no)

            # Replace the {{description}} with the respective follow up description given by the user from the database
            if answer.question_id.follow_up and answer.question_id.follow_up_answer.lower() == answer.answer.lower():
                text += '. '
                text += answer.question_id.report_description.replace('{{description}}',
                                                                      answer.description).capitalize()

            if answer.question_id.intent_id.intent_name.lower().strip() == 'grouped':

                report_answers[get_group_member(answer.question_id).strip()].append(
                    text)
            elif get_group_name(answer.question_id) is None:
                report_answers[answer.question_id.intent_id.intent_name].append(
                    text)
            else:
                report_answers[get_group_name(answer.question_id)].append(
                    text)

        # Add everything to context
        context = {'chat_id': chat_id,
                   'inquiries': inquiries,
                   'user_info': user_info,
                   'answers': report_answers}
        return render(request=request, template_name="dashboard/report.html", context=context)
    else:
        return redirect('account:login')


def email_report(request, name, email, sex, date, dob):
    if request.user.is_authenticated and request.user.is_superuser:
        chats = ChatInfo.objects.filter(name__iexact=name.lower(), email_address=email, sex=sex,
                                        date_of_birth=dob).order_by('-chat_ended')

        # Get inquiries
        inquiries = Intent.objects.filter(
            section_id__section_name='inquiries').values_list('intent_name', flat=True)

        email_report = None
        reports = []
        new_date_str = date[:19]
        date_obj = datetime.strptime(new_date_str, '%Y-%m-%d %H:%M:%S')
        date_str = date_obj.strftime("%Y-%m-%d %H:%M:%S")
        for chat in chats:
            report = get_report2(chat.chat_id)
            chat_ended = chat.chat_ended.strftime("%Y-%m-%d %H:%M:%S")
            if chat_ended == date_str:
                email_report = report
            reports.append(report)
        context = {"chats": chats, "reports": reports, "inquiries": inquiries}
        html_template = render_to_string('dashboard/mail_template.html',
                                         {'title': 'Email from Brantford', 'report': email_report})
        text_message = strip_tags(html_template)
        # email_send = EmailMultiAlternatives(
        #     'Email from Brantford Pediatrics',
        #     text_message,
        #     settings.EMAIL_HOST_USER,
        #     [email]
        # )
        # email_send.attach_alternative(html_template, "text/html")
        # email_send.send()

        # TODO DHRUVIL EMAIL
        mail_subject = 'Email from Brantford Pediatrics'
        send_email_visito.delay(
            mail_subject=mail_subject,
            mail_body=text_message,
            mail_attachment=html_template,
            to_email=email
        )

        # print(settings.EMAIL_HOST_USER)
        """subject = 'Email from Brantford Pediatrics'
        message = text_message
        email_from = settings.EMAIL_HOST_USER
        recipient_list = ['dilshersingh1@dcmail.ca', 'dilsher1995@gmail.com']
        send_mail(subject, message, email_from, recipient_list)"""

        return render(request=request, template_name="dashboard/user_chats.html", context=context)
    else:
        return redirect('account:login')


def download_report(request, name, email, sex, date, dob):
    if request.user.is_authenticated and request.user.is_superuser:
        chats = ChatInfo.objects.filter(name__iexact=name.lower(), email_address=email, sex=sex,
                                        date_of_birth=dob).order_by('-chat_ended')
        download_report = None
        reports = []
        new_date_str = date[:19]
        date_obj = datetime.strptime(new_date_str, '%Y-%m-%d %H:%M:%S')
        date_str = date_obj.strftime("%Y-%m-%d %H:%M:%S")
        for chat in chats:
            report = get_report2(chat.chat_id)
            chat_ended = chat.chat_ended.strftime("%Y-%m-%d %H:%M:%S")
            if chat_ended == date_str:
                download_report = report
            reports.append(report)
        context = {"chats": chats, "reports": reports}

        download_path = settings.DOWNLOAD_ROOT

        fout = os.path.join(download_path, str(
            download_report['chat_id']) + ".txt")
        fo = open(fout, "w")

        fo.write("Chat Id: " + str(download_report["chat_id"]) + '\n\n')

        fo.write("User Info" + '\n\n')

        fo.write("Name: " + download_report['user_info'].name + '\n')
        fo.write("Email address: " +
                 download_report['user_info'].email_address + '\n')
        fo.write("Date of Birth: " +
                 download_report['user_info'].date_of_birth.strftime("%Y-%m-%d") + '\n')
        fo.write("Age: {} months".format(download_report['user_age']) + '\n')
        fo.write("Sex: " + download_report['user_info'].sex + '\n')
        fo.write("First Visit: {}".format(
            download_report['user_info'].first_visit) + '\n')
        fo.write("Responded: {}".format(
            download_report['user_info'].responded) + '\n')
        fo.write("\n\n\n")

        answers = download_report['answers']

        for key in answers:
            fo.write(key + "\n\n")

            desc = answers[key]
            for line in desc:
                fo.write(line + "\n")

            fo.write("\n\n")
        fo.close()

        if os.path.exists(fout):
            with open(fout, 'rb') as fh:
                file_read = fh.read()

            response = HttpResponse(
                file_read, content_type='application/force-download')
            response['Content-Disposition'] = 'inline; filename=' + \
                                              os.path.basename(fout)

            os.remove(fout)

            return response
        raise Http404

    else:
        return redirect('account:login')


def download_report_xml(request, name, email, sex, date, dob):
    if request.user.is_authenticated and request.user.is_superuser:
        chats = ChatInfo.objects.filter(name__iexact=name.lower(), email_address=email, sex=sex,
                                        date_of_birth=dob).order_by('-chat_ended')
        download_report = None
        reports = []
        new_date_str = date[:19]
        date_obj = datetime.strptime(new_date_str, '%Y-%m-%d %H:%M:%S')
        date_str = date_obj.strftime("%Y-%m-%d %H:%M:%S")
        for chat in chats:
            report = get_report2(chat.chat_id)
            chat_ended = chat.chat_ended.strftime("%Y-%m-%d %H:%M:%S")
            if chat_ended == date_str:
                download_report = report
            reports.append(report)
        context = {"chats": chats, "reports": reports}
        print(download_report)
        download_path = settings.DOWNLOAD_ROOT

        report = ET.Element('report')
        user_attrs = ET.SubElement(report, 'user_attrs')
        name = ET.SubElement(user_attrs, 'name')
        email = ET.SubElement(user_attrs, 'email')
        dob = ET.SubElement(user_attrs, 'dob')
        age = ET.SubElement(user_attrs, 'age')
        sex = ET.SubElement(user_attrs, 'sex')
        first_visit = ET.SubElement(user_attrs, 'first_visit')
        responded = ET.SubElement(user_attrs, 'responded')

        name.text = download_report['user_info'].name
        email.text = download_report['user_info'].email_address
        dob.text = download_report['user_info'].date_of_birth.strftime(
            "%Y-%m-%d")
        age.text = str(download_report['user_age']) + " months"
        sex.text = download_report['user_info'].sex
        first_visit.text = str(download_report['user_info'].first_visit)
        responded.text = str(download_report['user_info'].responded)

        answers_tag = ET.SubElement(report, 'answers')
        answers = download_report['answers']

        for key in answers:
            key_tag = ET.SubElement(answers_tag, key)

            desc = answers[key]
            for line in desc:
                line_tag = ET.SubElement(key_tag, 'description')
                line_tag.text = line

        fout = os.path.join(download_path, str(
            download_report['chat_id']) + ".xml")
        mydata = ET.tostring(report)
        myfile = open(fout, "wb")
        myfile.write(mydata)
        myfile.close()

        if os.path.exists(fout):
            with open(fout, 'r') as fh:
                file_read = fh.read()

            response = HttpResponse(
                file_read, content_type='application/force-download')
            response['Content-Disposition'] = 'inline; filename=' + \
                                              os.path.basename(fout)

            os.remove(fout)

            return response
        raise Http404
    else:
        return redirect('account:login')


def calculate_age(born):
    today = timezone.now().date()
    difference = relativedelta.relativedelta(today, born)
    age = difference.years * 12 + difference.months
    return age


def get_segment_part(question_type, question_sub_order):
    if question_type == 24:
        return 1
    else:
        if question_sub_order > 0:
            return 2
        else:
            return 0


def get_group_name(question_id):
    if question_id.group_id is not None:
        return question_id.group_id.group_name
    else:
        return None


def get_group_member(question_id):
    try:
        qu = GroupQuestion.objects.get(question_id=question_id.question_id)
        return qu.group_id.group_for_each + " Details:"
    except ObjectDoesNotExist:
        return None
