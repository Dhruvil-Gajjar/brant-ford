from django.urls import path, include
from django.urls import re_path as url 
from . import views

app_name = 'dashboard'

urlpatterns = [

	path("user-chats/<str:name>/<str:email>/<str:sex>/<str:date_of_birth>/", views.user_chats, name="user-chats"),
	path("user-list/", views.get_user_list, name="user-list"),
	path('user-chats/<int:chat_id>/', views.report, name='report'),
	path('email-report/<str:name>/<str:email>/<str:sex>/<str:date>/<str:dob>', views.email_report, name='email-report'),
	path('download-report/<str:name>/<str:email>/<str:sex>/<str:date>/<str:dob>', views.download_report, name='download-report'),
	path('download-report-xml/<str:name>/<str:email>/<str:sex>/<str:date>/<str:dob>', views.download_report_xml, name='download-report-xml'),
]